import * as THREE from 'three';
import type { FuelMaterial } from './flameTypes';

export interface BurnerAssemblyHandle {
  group: THREE.Group;
  fuelMesh: THREE.Mesh;
  thermocoupleTip: THREE.Mesh;
  setFuelMaterial: (material: FuelMaterial) => void;
  setTipTemperatureGlow: (normTemp: number, tintHex: string) => void;
  dispose: () => void;
}

function createBrushedMetalRoughnessTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 256, 256);

  for (let y = 0; y < 256; y++) {
    const v = 105 + Math.floor(Math.sin(y * 0.7) * 18 + (Math.random() - 0.5) * 28);
    ctx.fillStyle = `rgb(${v},${v},${v})`;
    ctx.fillRect(0, y, 256, 1);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  tex.colorSpace = THREE.NoColorSpace;
  return tex;
}

function createDialScaleTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const cx = 256;
  const cy = 256;

  ctx.fillStyle = '#23201C';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle concentric lathe rings
  for (let r = 80; r < 245; r += 6) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255,255,255,0.035)';
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  // Degree calibration ticks on bezel
  for (let i = 0; i < 72; i++) {
    const a = (i / 72) * Math.PI * 2;
    const isMajor = i % 6 === 0;
    const r0 = isMajor ? 186 : 198;
    const r1 = 216;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
    ctx.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
    ctx.strokeStyle = isMajor ? 'rgba(236, 230, 216, 0.75)' : 'rgba(236, 230, 216, 0.28)';
    ctx.lineWidth = isMajor ? 2.5 : 1.2;
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(128, 128, 12, 128, 128, 124);
  grad.addColorStop(0, 'rgba(10, 8, 6, 0.72)');
  grad.addColorStop(0.5, 'rgba(10, 8, 6, 0.28)');
  grad.addColorStop(1, 'rgba(10, 8, 6, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createBurnerAssembly(maxAnisotropy: number, castShadows: boolean): BurnerAssemblyHandle {
  const group = new THREE.Group();
  const geometries: THREE.BufferGeometry[] = [];
  const materials: THREE.Material[] = [];
  const textures: THREE.Texture[] = [];

  const metalRoughTex = createBrushedMetalRoughnessTexture();
  metalRoughTex.anisotropy = maxAnisotropy;
  const dialTex = createDialScaleTexture();
  dialTex.anisotropy = maxAnisotropy;
  const shadowTex = createContactShadowTexture();
  textures.push(metalRoughTex, dialTex, shadowTex);

  // Materials with clear roughness/metalness contrast (>= 0.25 step)
  const anodizedMat = new THREE.MeshStandardMaterial({
    color: '#2B2723',
    roughness: 0.42,
    metalness: 0.86,
    roughnessMap: metalRoughTex,
  });
  const dialRingMat = new THREE.MeshStandardMaterial({
    map: dialTex,
    roughness: 0.45,
    metalness: 0.65,
  });
  const ceramicMat = new THREE.MeshStandardMaterial({
    color: '#D8D1C2',
    roughness: 0.88,
    metalness: 0.04,
  });
  const brassMat = new THREE.MeshStandardMaterial({
    color: '#C79B4B',
    roughness: 0.24,
    metalness: 0.92,
    roughnessMap: metalRoughTex,
  });
  const platinumMat = new THREE.MeshStandardMaterial({
    color: '#D2D6DC',
    roughness: 0.22,
    metalness: 0.96,
  });
  const fuelMat = new THREE.MeshPhysicalMaterial({
    color: '#E5DACA',
    roughness: 0.35,
    metalness: 0.05,
    clearcoat: 0.4,
    emissive: new THREE.Color('#B4411F'),
    emissiveIntensity: 0.28,
  });
  const tipGlowMat = new THREE.MeshStandardMaterial({
    color: '#FFF2CC',
    emissive: new THREE.Color('#E5693F'),
    emissiveIntensity: 1.4,
    roughness: 0.3,
    metalness: 0.2,
  });
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    depthWrite: false,
    opacity: 0.48,
  });
  materials.push(anodizedMat, dialRingMat, ceramicMat, brassMat, platinumMat, fuelMat, tipGlowMat, shadowMat);

  // 1. Soft radial contact shadow flush on Y = -1.35
  const baseFloorY = -1.35;
  const shadowGeo = new THREE.PlaneGeometry(3.8, 3.8);
  const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
  shadowMesh.rotation.x = -Math.PI / 2;
  shadowMesh.position.y = baseFloorY;
  group.add(shadowMesh);
  geometries.push(shadowGeo);

  // 2. Stepped anodized base plinth (LatheGeometry, bottom-center flush at baseFloorY)
  const plinthPoints = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(1.18, 0.0),
    new THREE.Vector2(1.18, 0.11),
    new THREE.Vector2(1.06, 0.16),
    new THREE.Vector2(0.92, 0.16),
    new THREE.Vector2(0.88, 0.28),
    new THREE.Vector2(0.55, 0.32),
    new THREE.Vector2(0.0, 0.32),
  ];
  const plinthGeo = new THREE.LatheGeometry(plinthPoints, 48);
  const plinthMesh = new THREE.Mesh(plinthGeo, anodizedMat);
  plinthMesh.position.y = baseFloorY + 0.01;
  plinthMesh.castShadow = castShadows;
  plinthMesh.receiveShadow = castShadows;
  group.add(plinthMesh);
  geometries.push(plinthGeo);

  // 3. Calibrated bezel disc (offset >= 0.02 on Y to prevent Z-fighting)
  const bezelGeo = new THREE.CylinderGeometry(0.9, 0.92, 0.03, 48);
  const bezelMesh = new THREE.Mesh(bezelGeo, dialRingMat);
  bezelMesh.position.y = baseFloorY + 0.19;
  bezelMesh.receiveShadow = castShadows;
  group.add(bezelMesh);
  geometries.push(bezelGeo);

  // 4. Ceramic thermal insulator collar (LatheGeometry)
  const ceramicPoints = [
    new THREE.Vector2(0.14, 0.0),
    new THREE.Vector2(0.46, 0.0),
    new THREE.Vector2(0.44, 0.18),
    new THREE.Vector2(0.34, 0.25),
    new THREE.Vector2(0.16, 0.25),
    new THREE.Vector2(0.14, 0.0),
  ];
  const ceramicGeo = new THREE.LatheGeometry(ceramicPoints, 36);
  const ceramicMesh = new THREE.Mesh(ceramicGeo, ceramicMat);
  ceramicMesh.position.y = baseFloorY + 0.33;
  ceramicMesh.castShadow = castShadows;
  ceramicMesh.receiveShadow = castShadows;
  group.add(ceramicMesh);
  geometries.push(ceramicGeo);

  // 5. Brass capillary fuel feed column & flared nozzle (LatheGeometry)
  const nozzlePoints = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(0.13, 0.0),
    new THREE.Vector2(0.11, 0.24),
    new THREE.Vector2(0.065, 0.32),
    new THREE.Vector2(0.065, 0.68),
    new THREE.Vector2(0.115, 0.78),
    new THREE.Vector2(0.085, 0.84),
    new THREE.Vector2(0.0, 0.84),
  ];
  const nozzleGeo = new THREE.LatheGeometry(nozzlePoints, 32);
  const nozzleMesh = new THREE.Mesh(nozzleGeo, brassMat);
  nozzleMesh.position.y = baseFloorY + 0.54;
  nozzleMesh.castShadow = castShadows;
  group.add(nozzleMesh);
  geometries.push(nozzleGeo);

  // 6. Specimen / fuel bead / wick centered at burner tip (Y ≈ 0.05)
  const fuelGeo = new THREE.SphereGeometry(0.14, 28, 28);
  const fuelMesh = new THREE.Mesh(fuelGeo, fuelMat);
  fuelMesh.position.set(0, 0.04, 0);
  group.add(fuelMesh);
  geometries.push(fuelGeo);

  // 7. Three perimeter optical guard posts + retaining halo ring
  const postGeo = new THREE.CylinderGeometry(0.022, 0.028, 0.76, 16);
  const postMesh = new THREE.InstancedMesh(postGeo, platinumMat, 3);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < 3; i++) {
    const angle = (i / 3) * Math.PI * 2 + Math.PI / 6;
    dummy.position.set(Math.cos(angle) * 0.74, baseFloorY + 0.56, Math.sin(angle) * 0.74);
    dummy.rotation.set(0, 0, 0);
    dummy.updateMatrix();
    postMesh.setMatrixAt(i, dummy.matrix);
  }
  postMesh.instanceMatrix.needsUpdate = true;
  postMesh.computeBoundingSphere();
  postMesh.castShadow = castShadows;
  group.add(postMesh);
  geometries.push(postGeo);

  const ringGeo = new THREE.TorusGeometry(0.74, 0.018, 12, 56);
  const ringMesh = new THREE.Mesh(ringGeo, anodizedMat);
  ringMesh.rotation.x = Math.PI / 2;
  ringMesh.position.y = baseFloorY + 0.94;
  group.add(ringMesh);
  geometries.push(ringGeo);

  // 8. Platinum-rhodium thermocouple probe arm + glowing weld bead
  const probeCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.68, baseFloorY + 0.25, 0.22),
    new THREE.Vector3(-0.56, baseFloorY + 0.72, 0.16),
    new THREE.Vector3(-0.34, -0.18, 0.08),
    new THREE.Vector3(-0.16, 0.08, 0.02),
  ]);
  const probeGeo = new THREE.TubeGeometry(probeCurve, 28, 0.015, 10, false);
  const probeMesh = new THREE.Mesh(probeGeo, platinumMat);
  group.add(probeMesh);
  geometries.push(probeGeo);

  const tipGeo = new THREE.SphereGeometry(0.032, 16, 16);
  const thermocoupleTip = new THREE.Mesh(tipGeo, tipGlowMat);
  thermocoupleTip.position.set(-0.15, 0.09, 0.02);
  group.add(thermocoupleTip);
  geometries.push(tipGeo);

  // 9. Igniter kanthal coil loop on right side
  const igniterCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.55, baseFloorY + 0.34, -0.2),
    new THREE.Vector3(0.46, baseFloorY + 0.78, -0.12),
    new THREE.Vector3(0.28, -0.12, -0.04),
    new THREE.Vector3(0.22, 0.02, 0.04),
    new THREE.Vector3(0.32, -0.06, 0.14),
  ]);
  const igniterGeo = new THREE.TubeGeometry(igniterCurve, 28, 0.013, 10, false);
  const igniterMesh = new THREE.Mesh(igniterGeo, brassMat);
  group.add(igniterMesh);
  geometries.push(igniterGeo);

  function setFuelMaterial(material: FuelMaterial) {
    if (material === 'pmma') {
      fuelMat.color.set('#EAE3D2');
      fuelMat.roughness = 0.24;
      fuelMat.clearcoat = 0.75;
      fuelMesh.scale.set(0.95, 1.35, 0.95);
    } else if (material === 'cotton') {
      fuelMat.color.set('#D8CEBC');
      fuelMat.roughness = 0.92;
      fuelMat.clearcoat = 0.0;
      fuelMesh.scale.set(1.22, 0.82, 1.22);
    } else {
      fuelMat.color.set('#F2C572');
      fuelMat.roughness = 0.12;
      fuelMat.clearcoat = 1.0;
      fuelMesh.scale.set(1.0, 1.0, 1.0);
    }
  }

  function setTipTemperatureGlow(normTemp: number, tintHex: string) {
    tipGlowMat.emissive.set(tintHex);
    tipGlowMat.emissiveIntensity = 0.7 + normTemp * 1.8;
    fuelMat.emissive.set(tintHex);
    fuelMat.emissiveIntensity = 0.15 + normTemp * 0.45;
  }

  function dispose() {
    geometries.forEach((g) => g.dispose());
    materials.forEach((m) => m.dispose());
    textures.forEach((t) => t.dispose());
  }

  return {
    group,
    fuelMesh,
    thermocoupleTip,
    setFuelMaterial,
    setTipTemperatureGlow,
    dispose,
  };
}
