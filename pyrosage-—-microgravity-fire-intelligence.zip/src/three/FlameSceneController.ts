import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { createBurnerAssembly, type BurnerAssemblyHandle } from './burnerAssembly';
import { createFlameShaderMaterial, type FlameLayerUniforms } from './flameShaders';
import {
  computeFlameVisuals,
  computeTelemetry,
  type CombustionParams,
  type FlameTelemetry,
} from './flameTypes';

export interface FlameControllerOptions {
  container: HTMLDivElement;
  mode: 'hero' | 'bench';
  isDarkTheme: boolean;
  initialParams?: CombustionParams;
  onTelemetry?: (telemetry: FlameTelemetry) => void;
  onContextLost?: (lost: boolean) => void;
}

// Pre-allocated scratch helpers (zero GC in render loop)
const _mat4 = new THREE.Matrix4();
const _pos = new THREE.Vector3();
const _quat = new THREE.Quaternion();
const _scale = new THREE.Vector3();
const _color = new THREE.Color();
const _targetCore = new THREE.Color();
const _targetMid = new THREE.Color();
const _targetOuter = new THREE.Color();
const _targetBase = new THREE.Color();
const _targetLight = new THREE.Color();

function detectSoftwareWebGL(): boolean {
  try {
    const probe = document.createElement('canvas');
    const gl = probe.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

interface EmberParticle {
  angle: number;
  radialSpeed: number;
  riseSpeed: number;
  phase: number;
  life: number;
  maxLife: number;
  size: number;
}

const EMBER_COUNT = 44;

export class FlameSceneController {
  private container: HTMLDivElement;
  private mode: 'hero' | 'bench';
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private burner: BurnerAssemblyHandle;
  private flameGroup: THREE.Group;
  private flameGeo: THREE.BufferGeometry;
  private flameLayers: Array<{ mesh: THREE.Mesh; uniforms: FlameLayerUniforms }> = [];
  private flameMaterials: THREE.ShaderMaterial[] = [];
  private emberMesh: THREE.InstancedMesh;
  private emberGeo: THREE.BufferGeometry;
  private emberMat: THREE.MeshBasicMaterial;
  private embers: EmberParticle[] = [];
  private flamePointLight: THREE.PointLight;
  private hemiLight: THREE.HemisphereLight;
  private keyLight: THREE.DirectionalLight;
  private envRT: THREE.WebGLRenderTarget;

  private isSoftwareGl: boolean;
  private reducedMotion: boolean;
  private frameId = 0;
  private disposed = false;
  private clock = new THREE.Clock();
  private elapsed = 0;
  private lastTelemetryEmit = 0;

  private autoCycle = false;
  private params: CombustionParams;
  private currentGravity: number;
  private currentHeightScale = 1.0;
  private currentWidthScale = 1.0;
  private currentTurbulence = 0.35;
  private currentSpeed = 1.3;
  private currentCoolFlame = 0.1;
  private currentBlueBase = 0.4;
  private currentIntensity = 1.2;

  private defaultCamPos = new THREE.Vector3();
  private defaultTarget = new THREE.Vector3(0, 0.08, 0);
  private resettingCamera = false;

  private resizeObserver: ResizeObserver;
  private onTelemetry?: (telemetry: FlameTelemetry) => void;
  private onContextLost?: (lost: boolean) => void;

  private handleContextLost = (e: Event) => {
    e.preventDefault();
    this.onContextLost?.(true);
  };

  private handleContextRestored = () => {
    this.onContextLost?.(false);
  };

  constructor(options: FlameControllerOptions) {
    this.container = options.container;
    this.mode = options.mode;
    this.onTelemetry = options.onTelemetry;
    this.onContextLost = options.onContextLost;
    this.autoCycle = options.mode === 'hero';
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    this.params = options.initialParams ?? {
      gravity: 0,
      oxygen: 21,
      pressure: 101,
      fuelFlow: 2,
      material: 'pmma',
    };
    this.currentGravity = this.params.gravity;

    this.isSoftwareGl = detectSoftwareWebGL();
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      alpha: false,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);
    this.renderer.setSize(width, height);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.addEventListener('webglcontextrestored', this.handleContextRestored);
    this.container.appendChild(this.renderer.domElement);

    // Scene & Studio Environment
    this.scene = new THREE.Scene();
    const bgHex = this.getBgHex(options.isDarkTheme);
    this.scene.background = new THREE.Color(bgHex);
    this.scene.fog = new THREE.FogExp2(bgHex, 0.045);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.envRT = pmrem.fromScene(new RoomEnvironment(), 0.04);
    this.scene.environment = this.envRT.texture;
    pmrem.dispose();

    // Camera
    this.camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 60);
    if (this.mode === 'hero') {
      this.defaultCamPos.set(0.35, 0.72, 4.15);
    } else {
      this.defaultCamPos.set(1.65, 0.88, 3.85);
    }
    this.camera.position.copy(this.defaultCamPos);

    // Damped OrbitControls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.copy(this.defaultTarget);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.07;
    this.controls.enablePan = false;
    this.controls.minDistance = 2.1;
    this.controls.maxDistance = 7.2;
    this.controls.minPolarAngle = 0.35;
    this.controls.maxPolarAngle = Math.PI * 0.56;
    this.controls.addEventListener('start', () => {
      this.resettingCamera = false;
    });

    // 3-Point Studio Lighting + Dynamic Flame PointLight
    this.keyLight = new THREE.DirectionalLight('#FFF0DC', 1.45);
    this.keyLight.position.set(3.5, 5.2, 3.8);
    if (!this.isSoftwareGl) {
      this.keyLight.castShadow = true;
      this.keyLight.shadow.mapSize.set(1024, 1024);
      this.keyLight.shadow.camera.near = 1;
      this.keyLight.shadow.camera.far = 15;
      const d = 2.4;
      this.keyLight.shadow.camera.left = -d;
      this.keyLight.shadow.camera.right = d;
      this.keyLight.shadow.camera.top = d;
      this.keyLight.shadow.camera.bottom = -d;
      this.keyLight.shadow.bias = -0.0005;
      this.keyLight.shadow.normalBias = 0.02;
    }
    this.scene.add(this.keyLight);

    this.hemiLight = new THREE.HemisphereLight('#9AB8D8', '#332C26', 0.85);
    this.scene.add(this.hemiLight);

    const rimLight = new THREE.DirectionalLight('#84B4DC', 0.65);
    rimLight.position.set(-3.2, 2.5, -3.5);
    this.scene.add(rimLight);

    this.flamePointLight = new THREE.PointLight('#E5693F', 3.2, 7.5, 1.8);
    this.flamePointLight.position.set(0, 0.25, 0);
    this.scene.add(this.flamePointLight);

    // Composite Procedural Burner Assembly
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    this.burner = createBurnerAssembly(maxAniso, !this.isSoftwareGl);
    this.burner.setFuelMaterial(this.params.material);
    this.scene.add(this.burner.group);

    // Multi-Layer Volumetric 3D Flame
    this.flameGroup = new THREE.Group();
    this.flameGroup.position.set(0, 0.14, 0);
    this.scene.add(this.flameGroup);

    this.flameGeo = new THREE.IcosahedronGeometry(0.68, 5);

    const layerConfigs = [
      { layerScale: 0.56, opacity: 0.94, blending: THREE.AdditiveBlending, order: 3 }, // Inner incandescent core
      { layerScale: 0.86, opacity: 0.78, blending: THREE.NormalBlending, order: 2 }, // Primary luminous mantle
      { layerScale: 1.14, opacity: 0.42, blending: THREE.AdditiveBlending, order: 4 }, // Outer radiant diffusion halo
    ];

    for (const cfg of layerConfigs) {
      const { material, uniforms } = createFlameShaderMaterial({
        layerScale: cfg.layerScale,
        opacity: cfg.opacity,
        blending: cfg.blending,
      });
      const mesh = new THREE.Mesh(this.flameGeo, material);
      mesh.renderOrder = cfg.order;
      this.flameGroup.add(mesh);
      this.flameLayers.push({ mesh, uniforms });
      this.flameMaterials.push(material);
    }

    // InstancedMesh Glowing Embers / Microgravity Sparks
    this.emberGeo = new THREE.SphereGeometry(0.018, 8, 8);
    this.emberMat = new THREE.MeshBasicMaterial({
      color: '#FFFFFF',
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.emberMesh = new THREE.InstancedMesh(this.emberGeo, this.emberMat, EMBER_COUNT);
    this.emberMesh.frustumCulled = false;
    this.emberMesh.renderOrder = 5;
    this.flameGroup.add(this.emberMesh);

    for (let i = 0; i < EMBER_COUNT; i++) {
      const maxLife = 1.6 + Math.random() * 2.2;
      this.embers.push({
        angle: (i / EMBER_COUNT) * Math.PI * 2 + Math.random() * 0.5,
        radialSpeed: 0.18 + Math.random() * 0.28,
        riseSpeed: 0.4 + Math.random() * 0.75,
        phase: Math.random() * Math.PI * 2,
        life: Math.random() * maxLife,
        maxLife,
        size: 0.45 + Math.random() * 0.9,
      });
    }

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    // ResizeObserver for responsive container
    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);

    // Start animation loop
    this.clock.start();
    this.tick();
  }

  private getBgHex(isDarkTheme: boolean): string {
    if (this.mode === 'hero') {
      return isDarkTheme ? '#181410' : '#1E1A16';
    }
    return isDarkTheme ? '#171310' : '#211C17';
  }

  public setTheme(isDarkTheme: boolean) {
    const bgHex = this.getBgHex(isDarkTheme);
    if (this.scene.background instanceof THREE.Color) {
      this.scene.background.set(bgHex);
    }
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.color.set(bgHex);
    }
  }

  public setParams(params: CombustionParams) {
    this.params = { ...params };
    this.burner.setFuelMaterial(params.material);
  }

  public setAutoCycle(enabled: boolean) {
    this.autoCycle = enabled;
  }

  public resetCamera() {
    this.resettingCamera = true;
  }

  private handleResize() {
    if (this.disposed) return;
    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private getEffectiveParams(t: number): CombustionParams {
    if (!this.autoCycle) return this.params;

    // Continuous smooth showcase of changing flame shapes & colors across NASA microgravity regimes:
    // 0g spherical terracotta -> 0g cool-flame cyan-violet -> 0.17g lunar ellipsoid -> 0.38g-0.85g Martian/buoyant plume
    const cycle = (t * 0.16) % 4;
    const smoothPhase = (x: number) => 0.5 - 0.5 * Math.cos(x * Math.PI);

    if (cycle < 1) {
      const k = smoothPhase(cycle);
      return {
        gravity: 0.0,
        oxygen: 21 + k * 4,
        pressure: 101,
        fuelFlow: 2.2,
        material: 'pmma',
      };
    } else if (cycle < 2) {
      const k = smoothPhase(cycle - 1);
      return {
        gravity: k * 0.17,
        oxygen: 21 - k * 3,
        pressure: 85,
        fuelFlow: 1.8,
        material: 'heptane', // triggers blue/cyan cool-flame transition!
      };
    } else if (cycle < 3) {
      const k = smoothPhase(cycle - 2);
      return {
        gravity: 0.17 + k * 0.35,
        oxygen: 24 + k * 12,
        pressure: 115,
        fuelFlow: 3.4,
        material: 'cotton', // bright golden-amber plume
      };
    } else {
      const k = smoothPhase(cycle - 3);
      return {
        gravity: 0.52 * (1 - k),
        oxygen: 36 - k * 15,
        pressure: 101,
        fuelFlow: 2.2,
        material: 'pmma',
      };
    }
  }

  private tick = () => {
    if (this.disposed) return;

    const rawDelta = Math.min(0.05, this.clock.getDelta());
    const dt = this.reducedMotion ? rawDelta * 0.15 : rawDelta;
    this.elapsed += dt;

    const effective = this.getEffectiveParams(this.elapsed);
    const visuals = computeFlameVisuals(effective, this.elapsed * 0.85);
    const telemetry = computeTelemetry(effective);

    // Smooth exponential damping for shape & color transitions
    const dampK = 5.5;
    const alpha = 1 - Math.exp(-dampK * Math.max(dt, 0.016));

    this.currentGravity = THREE.MathUtils.lerp(this.currentGravity, visuals.gravity, alpha);
    this.currentHeightScale = THREE.MathUtils.lerp(this.currentHeightScale, visuals.heightScale, alpha);
    this.currentWidthScale = THREE.MathUtils.lerp(this.currentWidthScale, visuals.widthScale, alpha);
    this.currentTurbulence = THREE.MathUtils.lerp(this.currentTurbulence, visuals.turbulence, alpha);
    this.currentSpeed = THREE.MathUtils.lerp(this.currentSpeed, visuals.speed, alpha);
    this.currentCoolFlame = THREE.MathUtils.lerp(this.currentCoolFlame, visuals.coolFlameMix, alpha);
    this.currentBlueBase = THREE.MathUtils.lerp(this.currentBlueBase, visuals.blueBaseMix, alpha);
    this.currentIntensity = THREE.MathUtils.lerp(this.currentIntensity, visuals.intensity, alpha);

    _targetCore.set(visuals.coreHex);
    _targetMid.set(visuals.midHex);
    _targetOuter.set(visuals.outerHex);
    _targetBase.set(visuals.baseHex);
    _targetLight.set(visuals.lightHex);

    for (const layer of this.flameLayers) {
      const u = layer.uniforms;
      u.uTime.value = this.elapsed;
      u.uGravity.value = this.currentGravity;
      u.uHeightScale.value = this.currentHeightScale;
      u.uWidthScale.value = this.currentWidthScale;
      u.uTurbulence.value = this.currentTurbulence;
      u.uSpeed.value = this.currentSpeed;
      u.uCoolFlame.value = this.currentCoolFlame;
      u.uBlueBase.value = this.currentBlueBase;
      u.uIntensity.value = this.currentIntensity;
      u.uColorCore.value.lerp(_targetCore, alpha);
      u.uColorMid.value.lerp(_targetMid, alpha);
      u.uColorOuter.value.lerp(_targetOuter, alpha);
      u.uColorBase.value.lerp(_targetBase, alpha);
    }

    // Sync flame point light and thermocouple glow
    const flicker = 0.92 + Math.sin(this.elapsed * 9.5) * 0.05 + Math.cos(this.elapsed * 14.3) * 0.04;
    this.flamePointLight.color.lerp(_targetLight, alpha);
    this.flamePointLight.intensity = (2.6 + this.currentIntensity * 0.9) * flicker;
    this.flamePointLight.position.y = 0.22 + this.currentGravity * 0.35;

    this.burner.setTipTemperatureGlow((telemetry.temperatureK - 400) / 700, visuals.midHex);
    if (this.autoCycle) {
      this.burner.setFuelMaterial(effective.material);
    }

    // Update InstancedMesh ember particles
    const g = this.currentGravity;
    for (let i = 0; i < EMBER_COUNT; i++) {
      const e = this.embers[i];
      e.life += dt * (0.7 + g * 0.8);
      if (e.life >= e.maxLife) {
        e.life = 0;
        e.angle = Math.random() * Math.PI * 2;
      }
      const p = e.life / e.maxLife;
      const fade = Math.sin(p * Math.PI);

      // In 0g, embers drift radially outward; in higher g, they spiral upward in buoyant plume
      const radialSpread = (0.14 + p * (0.85 - g * 0.45)) * this.currentWidthScale;
      const swirl = e.angle + this.elapsed * (0.35 + g * 1.1) + p * 1.8;
      const x = Math.cos(swirl) * radialSpread;
      const z = Math.sin(swirl) * radialSpread;
      const yRadial = Math.sin(e.phase + p * Math.PI * 0.5) * 0.35 * (1 - g * 0.6);
      const yBuoyant = p * e.riseSpeed * (0.3 + g * 1.9) * this.currentHeightScale;
      const y = yRadial + yBuoyant;

      _pos.set(x, y, z);
      const s = e.size * fade * (0.65 + this.currentIntensity * 0.25);
      _scale.set(s, s * (1 + g * 1.2), s);
      _mat4.compose(_pos, _quat, _scale);
      this.emberMesh.setMatrixAt(i, _mat4);

      _color.copy(_targetCore).lerp(_targetOuter, p * 0.85);
      this.emberMesh.setColorAt(i, _color);
    }
    this.emberMesh.instanceMatrix.needsUpdate = true;
    if (this.emberMesh.instanceColor) {
      this.emberMesh.instanceColor.needsUpdate = true;
    }

    // Damped camera reset if requested
    if (this.resettingCamera) {
      const camAlpha = 1 - Math.exp(-6.0 * Math.max(dt, 0.016));
      this.camera.position.lerp(this.defaultCamPos, camAlpha);
      this.controls.target.lerp(this.defaultTarget, camAlpha);
      if (this.camera.position.distanceTo(this.defaultCamPos) < 0.02) {
        this.camera.position.copy(this.defaultCamPos);
        this.controls.target.copy(this.defaultTarget);
        this.resettingCamera = false;
      }
    }

    this.controls.update();
    this.renderer.render(this.scene, this.camera);

    // Emit throttled telemetry (~10Hz) for hero labels
    if (this.onTelemetry && this.elapsed - this.lastTelemetryEmit > 0.1) {
      this.lastTelemetryEmit = this.elapsed;
      this.onTelemetry(telemetry);
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private afterDraw(cb: () => void) {
    if (this.disposed) return;
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.resizeObserver.disconnect();
    this.controls.dispose();
    this.burner.dispose();
    this.flameGeo.dispose();
    this.flameMaterials.forEach((m) => m.dispose());
    this.emberGeo.dispose();
    this.emberMat.dispose();
    this.envRT.dispose();
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.removeEventListener('webglcontextrestored', this.handleContextRestored);
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
