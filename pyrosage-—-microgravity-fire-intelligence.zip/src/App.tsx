import { useEffect, useMemo, useRef, useState, type ChangeEvent } from 'react';
import { FlameViewport } from './components/FlameViewport';
import { computeTelemetry, type CombustionParams, type FuelMaterial } from './three/flameTypes';

interface SpecimenItem {
  name: string;
  gravity: '0g' | 'lunar' | 'martian';
  imageUrl: string | null;
  statusText: string;
}

const SAMPLE_DEFS: Array<[string, string, number]> = [
  ['FLEX-2 Flame', '#B4411F', 1],
  ['ISS Candle', '#E5693F', 2],
  ['Drop Tower', '#1F4D45', 3],
  ['SoFIE Test', '#B98A2E', 4],
];

const BASE_SCORES: Array<[number, number, number, string]> = [
  [0.86, 0.62, 0.55, 'Needs leaching test'],
  [0.78, 0.66, 0.7, 'Low coverage'],
  [0.71, 0.48, 0.82, 'Needs leaching test'],
  [0.36, 0.4, 0.74, 'Low coverage · alkaline'],
];

const PHASES = ['goethite', 'hematite', 'gibbsite', 'kaolinite', 'quartz'];
const ADSORBATES = ['arsenate', 'arsenite', 'phosphate', 'silicate'];
const ANALYSIS_STAGES = [
  'Plan the screening matrix',
  'Read the benchmark gate',
  'Binding energies, arsenate to silicate',
  'Score, grade, apply gates',
  'Draft the jar-test protocol',
];
const TOTAL_JOBS = 36;

function makeSampleTextureUrl(color: string, seed: number): string {
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='300' height='375'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3' seed='${seed}'/><feColorMatrix values='0 0 0 0 .1 0 0 0 0 .06 0 0 0 0 .04 0 0 0 1.1 -.35'/></filter><rect width='300' height='375' fill='${color}'/><rect width='300' height='375' filter='url(#n)'/><circle cx='232' cy='72' r='25' fill='#CFC8B8' stroke='#8A8372' stroke-width='3'/></svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

export default function App() {
  const [step, setStep] = useState<number>(0);
  const [isDark, setIsDark] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.matchMedia('(prefers-color-scheme: dark)').matches : false,
  );
  const benchRef = useRef<HTMLElement | null>(null);
  const resetBenchCamRef = useRef<(() => void) | null>(null);

  // Step 01: Fiction Combustion state
  const [params, setParams] = useState<CombustionParams>({
    gravity: 0,
    oxygen: 21,
    pressure: 101,
    fuelFlow: 2,
    material: 'pmma',
  });
  const [benchAutoCycle, setBenchAutoCycle] = useState<boolean>(false);

  // Step 02: Specimens state
  const [specimens, setSpecimens] = useState<SpecimenItem[]>(() =>
    [0, 1, 2, 3].map(() => ({
      name: '',
      gravity: '0g',
      imageUrl: null,
      statusText: 'Add photo',
    })),
  );

  // Step 03: Analysis state
  const [jobCount, setJobCount] = useState<number>(0);
  const [isRunningAnalysis, setIsRunningAnalysis] = useState<boolean>(false);
  const [hasCompletedAnalysis, setHasCompletedAnalysis] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);
  const logBoxRef = useRef<HTMLDivElement | null>(null);
  const timerRef = useRef<number | null>(null);

  // Step 04: Ranking weights state
  const [weights, setWeights] = useState<[number, number, number]>([50, 30, 20]);

  useEffect(() => {
    document.documentElement.dataset.theme = isDark ? 'dark' : 'light';
  }, [isDark]);

  useEffect(() => {
    return () => {
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (logBoxRef.current) {
      logBoxRef.current.scrollTop = logBoxRef.current.scrollHeight;
    }
  }, [logs]);

  const telemetry = useMemo(() => computeTelemetry(params), [params]);

  const goToStep = (nextStep: number, scroll = true) => {
    setStep(nextStep);
    if (scroll && benchRef.current) {
      const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      benchRef.current.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth' });
    }
  };

  const updateParam = <K extends keyof CombustionParams>(key: K, value: CombustionParams[K]) => {
    setBenchAutoCycle(false);
    setParams((prev) => ({ ...prev, [key]: value }));
  };

  const applyGravityPreset = (g: number) => {
    setBenchAutoCycle(false);
    setParams((prev) => ({ ...prev, gravity: g }));
  };

  const handleSpecimenUpload = (idx: number, e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setSpecimens((prev) =>
      prev.map((item, i) => (i === idx ? { ...item, imageUrl: url, statusText: 'Photo added' } : item)),
    );
  };

  const loadNasaSamples = () => {
    setSpecimens((prev) =>
      prev.map((item, i) => {
        const [sampleName, color, seed] = SAMPLE_DEFS[i];
        return {
          ...item,
          name: sampleName,
          imageUrl: makeSampleTextureUrl(color, seed),
          statusText: 'Sample image',
        };
      }),
    );
  };

  const beginScreening = () => {
    if (isRunningAnalysis) return;
    if (timerRef.current !== null) window.clearInterval(timerRef.current);

    setIsRunningAnalysis(true);
    setHasCompletedAnalysis(false);
    setJobCount(0);
    setLogs([]);

    let n = 0;
    timerRef.current = window.setInterval(() => {
      n += 1;
      setJobCount(n);

      if (n > 5 && n < 33) {
        const entry = `job ${String(n).padStart(2, '0')} · ${PHASES[n % 5]} · ${ADSORBATES[n % 4]} · ${
          n % 2 ? 'mono' : 'bi'
        }dentate`;
        setLogs((prev) => [...prev, entry]);
      }

      if (n >= TOTAL_JOBS) {
        if (timerRef.current !== null) {
          window.clearInterval(timerRef.current);
          timerRef.current = null;
        }
        setIsRunningAnalysis(false);
        setHasCompletedAnalysis(true);
      }
    }, 110);
  };

  const activeStageIndex =
    jobCount === 0 && !isRunningAnalysis && !hasCompletedAnalysis
      ? -1
      : jobCount < 3
        ? 0
        : jobCount < 6
          ? 1
          : jobCount < 33
            ? 2
            : jobCount < 35
              ? 3
              : 4;

  const rankedItems = useMemo(() => {
    const totalW = weights[0] + weights[1] + weights[2] || 1;
    return SAMPLE_DEFS.map((def, i) => {
      const name = specimens[i].name.trim() || def[0];
      const base = BASE_SCORES[i];
      const score = (100 * (weights[0] * base[0] + weights[1] * base[1] + weights[2] * base[2])) / totalW;
      return {
        name,
        score,
        flag: base[3],
        grade: score >= 68 ? 'B' : score >= 52 ? 'C' : 'D',
      };
    }).sort((a, b) => b.score - a.score);
  }, [specimens, weights]);

  return (
    <>
      <header className="top">
        <div className="wrap">
          <a className="mark" href="#top">
            Pyro<em>Sage</em>
          </a>
          <nav aria-label="Workflow">
            {['01 Environment', '02 Specimens', '03 Analyze', '04 Ranking'].map((label, idx) => (
              <button
                key={label}
                type="button"
                aria-current={step === idx ? 'step' : 'false'}
                onClick={() => goToStep(idx)}
              >
                {label}
              </button>
            ))}
          </nav>
          <button
            type="button"
            className="ghost"
            aria-label="Switch light and dark theme"
            onClick={() => setIsDark((prev) => !prev)}
          >
            ◐
          </button>
        </div>
      </header>

      <main className="wrap" id="top">
        <section className="hero">
          <div>
            <p className="k">NASA PSI · microgravity combustion · fire safety</p>
            <h1>
              Read the <em>flame</em> that doesn&apos;t rise.
            </h1>
            <p className="lede">
              Input mission parameters or upload flame imagery, and PyroSage ranks fire hazards for lunar and Martian
              missions using decades of microgravity combustion data.
            </p>
            <div className="cta">
              <button type="button" className="btn" onClick={() => goToStep(0)}>
                Open the bench →
              </button>
              <p className="k">Decision support, not a flight-safety certificate</p>
            </div>
          </div>

          <figure className="core">
            <FlameViewport mode="hero" isDarkTheme={isDark} params={params} autoCycle />
          </figure>
        </section>

        <ul className="facts">
          <li>
            <b>36+ yrs</b>
            <p className="k">NASA microgravity fire experiments (FLEX, SoFIE, CIR)</p>
          </li>
          <li>
            <b>0.17g / 0.38g</b>
            <p className="k">Lunar / Martian gravity environments to model</p>
          </li>
          <li>
            <b>One image</b>
            <p className="k">Flame photo that reveals its physics</p>
          </li>
        </ul>

        <section id="bench" ref={benchRef}>
          <div className="bh2">
            <h2>The bench</h2>
            <p className="k">Step {step + 1} of 4</p>
          </div>

          {step === 0 && (
            <div className="panel">
              <h2>
                <small>01</small>Fiction <span>Combustion</span>
              </h2>
              <p className="note">
                Test hypothetical fire scenarios. Adjust parameters to see how flames change color and shape across
                gravity levels using NASA combustion physics.
              </p>

              <div className="g2">
                <div>
                  <div className="ledger">
                    <label>
                      <span>
                        Gravity level<i>g</i>
                      </span>
                      <input
                        type="number"
                        value={params.gravity}
                        min={0}
                        max={1}
                        step={0.01}
                        onChange={(e) =>
                          updateParam('gravity', Math.min(1, Math.max(0, Number(e.target.value) || 0)))
                        }
                      />
                    </label>
                    <label>
                      <span>
                        Oxygen concentration<i>%</i>
                      </span>
                      <input
                        type="range"
                        min={15}
                        max={40}
                        value={params.oxygen}
                        onChange={(e) => updateParam('oxygen', Number(e.target.value))}
                      />
                    </label>
                    <label>
                      <span>
                        Cabin pressure<i>kPa</i>
                      </span>
                      <input
                        type="number"
                        value={params.pressure}
                        min={10}
                        max={200}
                        onChange={(e) =>
                          updateParam('pressure', Math.min(200, Math.max(10, Number(e.target.value) || 10)))
                        }
                      />
                    </label>
                    <label>
                      <span>
                        Fuel flow rate<i>mm/s</i>
                      </span>
                      <input
                        type="number"
                        value={params.fuelFlow}
                        min={0.1}
                        max={20}
                        step={0.1}
                        onChange={(e) =>
                          updateParam('fuelFlow', Math.min(20, Math.max(0.1, Number(e.target.value) || 0.1)))
                        }
                      />
                    </label>
                    <label>
                      <span>
                        Material type<i>PSI dataset</i>
                      </span>
                      <select
                        value={params.material}
                        onChange={(e) => updateParam('material', e.target.value as FuelMaterial)}
                      >
                        <option value="pmma">PMMA (Plexiglass)</option>
                        <option value="cotton">Cotton fabric</option>
                        <option value="heptane">Heptane liquid</option>
                      </select>
                    </label>
                  </div>

                  <dl className="read">
                    <div>
                      <dt>Flame regime</dt>
                      <dd>{telemetry.regime}</dd>
                    </div>
                    <div>
                      <dt>Spread risk</dt>
                      <dd>{telemetry.spreadRisk}</dd>
                    </div>
                    <div>
                      <dt>Cool flame</dt>
                      <dd>{telemetry.coolFlame}</dd>
                    </div>
                  </dl>
                </div>

                <figure className="chart">
                  <FlameViewport
                    mode="bench"
                    isDarkTheme={isDark}
                    params={params}
                    autoCycle={benchAutoCycle}
                    onResetViewRef={(fn) => {
                      resetBenchCamRef.current = fn;
                    }}
                  />
                  <figcaption className="chart-controls">
                    <span className="k">Predicted 3D flame · drag to orbit · dynamic thermal palette</span>
                    <div className="preset-row">
                      <button
                        type="button"
                        className="preset-btn"
                        aria-pressed={!benchAutoCycle && params.gravity === 0}
                        onClick={() => applyGravityPreset(0)}
                      >
                        0g
                      </button>
                      <button
                        type="button"
                        className="preset-btn"
                        aria-pressed={!benchAutoCycle && params.gravity === 0.17}
                        onClick={() => applyGravityPreset(0.17)}
                      >
                        0.17g Lunar
                      </button>
                      <button
                        type="button"
                        className="preset-btn"
                        aria-pressed={!benchAutoCycle && params.gravity === 0.38}
                        onClick={() => applyGravityPreset(0.38)}
                      >
                        0.38g Mars
                      </button>
                      <button
                        type="button"
                        className="preset-btn"
                        aria-pressed={!benchAutoCycle && params.gravity === 1}
                        onClick={() => applyGravityPreset(1)}
                      >
                        1.0g Earth
                      </button>
                      <button
                        type="button"
                        className="preset-btn"
                        aria-pressed={benchAutoCycle}
                        onClick={() => setBenchAutoCycle((prev) => !prev)}
                      >
                        {benchAutoCycle ? 'Cycling' : 'Cycle all'}
                      </button>
                      <button
                        type="button"
                        className="preset-btn"
                        onClick={() => resetBenchCamRef.current?.()}
                      >
                        Reset view
                      </button>
                    </div>
                  </figcaption>
                </figure>
              </div>

              <div className="row">
                <span className="k">Physics: buoyancy absent below 0.1g · Marangoni flow dominates</span>
                <button type="button" className="btn" onClick={() => goToStep(1)}>
                  Specimens →
                </button>
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="panel">
              <h2>
                <small>02</small>The <span>specimens</span>
              </h2>
              <p className="note">
                Upload flame images from experiments or missions. Up to four. AI extracts geometric signatures
                (symmetry, fractal dimension, centroid jitter).
              </p>

              <div className="plates">
                {specimens.map((item, idx) => (
                  <article key={idx}>
                    <label
                      className={`plate ${item.imageUrl ? 'has' : ''}`}
                      style={item.imageUrl ? { backgroundImage: `url("${item.imageUrl}")` } : undefined}
                    >
                      <input
                        type="file"
                        accept="image/*"
                        aria-label={`Photo for specimen ${idx + 1}`}
                        onChange={(e) => handleSpecimenUpload(idx, e)}
                      />
                      <b>S{idx + 1}</b>
                      <span>{item.statusText}</span>
                    </label>

                    <input
                      className="nm"
                      value={item.name}
                      placeholder="Experiment name"
                      aria-label={`Name of specimen ${idx + 1}`}
                      onChange={(e) => {
                        const value = e.target.value;
                        setSpecimens((prev) =>
                          prev.map((s, i) => (i === idx ? { ...s, name: value } : s)),
                        );
                      }}
                    />

                    <div className="seg" role="group" aria-label={`Gravity of specimen ${idx + 1}`}>
                      {(['0g', 'lunar', 'martian'] as const).map((grav) => (
                        <button
                          key={grav}
                          type="button"
                          aria-pressed={item.gravity === grav}
                          onClick={() =>
                            setSpecimens((prev) =>
                              prev.map((s, i) => (i === idx ? { ...s, gravity: grav } : s)),
                            )
                          }
                        >
                          {grav}
                        </button>
                      ))}
                    </div>
                  </article>
                ))}
              </div>

              <div className="row">
                <button type="button" className="btn btn-outline" onClick={loadNasaSamples}>
                  Load NASA samples
                </button>
                <button type="button" className="btn" onClick={() => goToStep(2)}>
                  Analyze →
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="panel">
              <h2>
                <small>03</small>The <span>analysis</span>
              </h2>
              <p className="note">SI engine applies computer vision and combustion physics to rank hazards.</p>

              <div className="g2">
                <div>
                  <div className="big" aria-live="polite">
                    {String(jobCount).padStart(2, '0')}
                    <small>/ 36 jobs</small>
                  </div>
                  <div className="bar">
                    <i style={{ width: `${(jobCount / TOTAL_JOBS) * 100}%` }} />
                  </div>
                  <button
                    type="button"
                    className="btn"
                    disabled={isRunningAnalysis}
                    onClick={beginScreening}
                  >
                    {hasCompletedAnalysis ? 'Run again' : 'Begin screening'}
                  </button>
                </div>

                <div>
                  <ol className="stages">
                    {ANALYSIS_STAGES.map((stageLabel, i) => {
                      const cls =
                        hasCompletedAnalysis || (activeStageIndex > i && activeStageIndex !== -1)
                          ? 'done'
                          : activeStageIndex === i
                            ? 'now'
                            : '';
                      return (
                        <li key={stageLabel} className={cls}>
                          {stageLabel}
                        </li>
                      );
                    })}
                  </ol>
                  <div className="log" ref={logBoxRef} aria-hidden="true">
                    {logs.map((line, idx) => (
                      <div key={idx}>{line}</div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="row">
                <span />
                <button
                  type="button"
                  className="btn"
                  disabled={!hasCompletedAnalysis}
                  onClick={() => goToStep(3)}
                >
                  Ranking →
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="panel">
              <h2>
                <small>04</small>The <span>ranking</span>
              </h2>
              <div className="gate">
                <b>Gate: provisional</b>
                <span className="note" style={{ margin: 0 }}>
                  Illustrative values for layout only. Real runs stamp their own benchmark state on every card.
                </span>
              </div>

              <div className="w">
                {[
                  { id: 'w0', label: 'Binding strength' },
                  { id: 'w1', label: 'Selectivity' },
                  { id: 'w2', label: 'Local practicality' },
                ].map((wItem, idx) => (
                  <div key={wItem.id}>
                    <label htmlFor={wItem.id}>{wItem.label}</label>
                    <input
                      id={wItem.id}
                      type="range"
                      min={0}
                      max={100}
                      value={weights[idx]}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setWeights((prev) => {
                          const next: [number, number, number] = [...prev] as [number, number, number];
                          next[idx] = val;
                          return next;
                        });
                      }}
                    />
                  </div>
                ))}
              </div>

              <ol id="rank">
                {rankedItems.map((item, i) => (
                  <li key={item.name}>
                    <span className="rk">{i + 1}</span>
                    <div>
                      <h3>{item.name}</h3>
                      <p className="k">{item.flag}</p>
                    </div>
                    <div className="meter">
                      <i style={{ width: `${item.score}%` }} />
                    </div>
                    <b className="sc">{Math.round(item.score)}</b>
                    <span className="gr" title="Confidence grade">
                      {item.grade}
                    </span>
                  </li>
                ))}
              </ol>

              <details>
                <summary>Mission safety protocol for top three</summary>
                <table>
                  <tbody>
                    <tr>
                      <th>Suppression</th>
                      <td>N₂ purge · water mist · CO₂ (gravity-dependent)</td>
                    </tr>
                    <tr>
                      <th>Detection</th>
                      <td>IR thermography · UV flame sensors · smoke opacity</td>
                    </tr>
                    <tr>
                      <th>Replicates</th>
                      <td>3, plus a positive and a negative control</td>
                    </tr>
                    <tr>
                      <th>Prediction</th>
                      <td>Order of removal follows the ranking. A reversed order falsifies it.</td>
                    </tr>
                  </tbody>
                </table>
                <p className="note">
                  Treat spent media as arsenic-bearing waste. Do not drink treated water until an accredited laboratory
                  has verified it.
                </p>
              </details>
            </div>
          )}
        </section>
      </main>

      <footer className="wrap">
        <p className="k">PyroSage · prepared for NASA Space Apps</p>
        <p className="k">Decision support, not a flight-safety certificate</p>
      </footer>
    </>
  );
}
