import { useEffect, useRef, useState } from 'react';
import { FlameSceneController } from '../three/FlameSceneController';
import { computeTelemetry, type CombustionParams, type FlameTelemetry } from '../three/flameTypes';

interface FlameViewportProps {
  mode: 'hero' | 'bench';
  isDarkTheme: boolean;
  params: CombustionParams;
  autoCycle?: boolean;
  onResetViewRef?: (resetFn: () => void) => void;
  className?: string;
}

export function FlameViewport({
  mode,
  isDarkTheme,
  params,
  autoCycle = mode === 'hero',
  onResetViewRef,
  className = '',
}: FlameViewportProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const controllerRef = useRef<FlameSceneController | null>(null);
  const [contextLost, setContextLost] = useState(false);
  const [heroTelemetry, setHeroTelemetry] = useState<FlameTelemetry>(() => computeTelemetry(params));

  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    const controller = new FlameSceneController({
      container: el,
      mode,
      isDarkTheme,
      initialParams: params,
      onTelemetry: mode === 'hero' ? (t) => setHeroTelemetry(t) : undefined,
      onContextLost: (lost) => setContextLost(lost),
    });
    controller.setAutoCycle(autoCycle);
    controllerRef.current = controller;

    if (onResetViewRef) {
      onResetViewRef(() => controller.resetCamera());
    }

    return () => {
      controller.dispose();
      controllerRef.current = null;
    };
    // Initialize WebGL scene once per mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  useEffect(() => {
    controllerRef.current?.setTheme(isDarkTheme);
  }, [isDarkTheme]);

  useEffect(() => {
    controllerRef.current?.setParams(params);
  }, [params]);

  useEffect(() => {
    controllerRef.current?.setAutoCycle(autoCycle);
  }, [autoCycle]);

  const activeTelemetry = mode === 'hero' ? heroTelemetry : computeTelemetry(params);

  return (
    <div className={`flame-stage ${mode === 'hero' ? 'flame-stage--hero' : 'flame-stage--bench'} ${className}`}>
      <div
        ref={mountRef}
        className="flame-canvas-mount"
        role="img"
        aria-label={
          mode === 'hero'
            ? 'Interactive 3D microgravity flame cycling through spherical, ellipsoidal, and buoyant combustion regimes'
            : 'Interactive 3D flame geometry and thermal color simulation'
        }
      />

      {/* Semantic unboxed scientific HUD annotations matching PyroSage aesthetic */}
      {mode === 'hero' ? (
        <div className="flame-hud flame-hud--hero" aria-hidden="true">
          <div className="flame-hud-col">
            <span>{activeTelemetry.modeLabel}</span>
            <span>{activeTelemetry.coolFlame === 'Likely' ? 'COOL FLAME' : 'DIFFUSION'}</span>
            <span>{activeTelemetry.flowLabel}</span>
          </div>
          <div className="flame-hud-right">
            <span>T∞</span>
            <span className="tabular-nums">{activeTelemetry.temperatureK}K</span>
          </div>
        </div>
      ) : (
        <div className="flame-hud flame-hud--bench" aria-hidden="true">
          <span className="tabular-nums">
            g={params.gravity.toFixed(2)} · {params.oxygen}% O₂ · {params.pressure}kPa
          </span>
          <span className="tabular-nums">T∞ {activeTelemetry.temperatureK}K</span>
        </div>
      )}

      {contextLost && (
        <div className="flame-fallback">
          <span>WebGL context paused — 3D flame renderer recovering</span>
        </div>
      )}
    </div>
  );
}
