# Pure 3D Flame Simulator — Implementation Plan

Strip away all multi-step workflows, hero editorial sections, specimen uploaders, analysis queues, rankings, and 3D burner hardware so the application focuses exclusively on a pure, animated floating 3D flame paired with a crisp side parameter console.

## User Review & Critical Decisions

> [!IMPORTANT]
> All four core product and visual choices have been confirmed from the clarification step and override the previous multi-page PyroSage layout:

- **Layout Architecture**: Split screen with a fixed-width side parameter panel (`340px` on desktop, stacked cleanly below the canvas on mobile) alongside a `flex-1` 3D flame viewport.
- **3D Scene Scope**: Pure floating volumetric flame and glowing micro-embers only—all burner plinths, nozzles, ceramic collars, thermocouple probes, and guard posts will be removed from the scene and codebase.
- **Changeable Parameters**: Gravity (`0g`–`1g`), Oxygen concentration (`15%`–`40%`), Cabin pressure (`10`–`200 kPa`), Fuel flow rate (`0.1`–`20 mm/s`), and Material type (`PMMA`, `Cotton`, `Heptane`), plus quick gravity presets, an Auto-Cycle mode toggle, and a Reset View control.
- **Visual Backdrop**: Deep obsidian dark studio backdrop (`#07090E` / `#0B0E17`) for maximum flame contrast, luminous color fidelity, and zero light-theme clutter.

---

## 1. Overview & Core Concept

- **What It Does**: Renders a continuous, physically inspired Three.js 3D volumetric flame floating in a dark obsidian viewport. Adjusting any parameter smoothly morphs the flame's 3D silhouette (from a spherical `0g` diffusion shell to a lunar ellipsoid to a buoyant `1g` flickering teardrop plume), shifts its multi-stop thermal/chemiluminescent color gradient (white-gold core, amber-terracotta mantle, blue CH* base rim, or cyan-indigo cool-flame state), and updates live telemetry readouts.
- **Target Audience**: Users and researchers who want an immediate, distraction-free interactive sandbox to sculpt and inspect animated 3D combustion shapes and colors.
- **Key Value**: Zero navigation friction—the 3D flame and its physics controls occupy 100% of the viewport from the first frame.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Immediate Launch**: The page opens directly into the split-screen console with the pure 3D flame actively burning and subtly breathing in `0g` spherical mode against a deep obsidian canvas.
2. **Parameter Sculpting**: Dragging sliders or editing numeric inputs (`Gravity`, `Oxygen`, `Pressure`, `Fuel Flow`, `Material`) immediately damps the 3D flame's geometry, turbulence speed, ember trajectories, and thermal color palette in real time.
3. **Quick Inspection**: Clicking gravity preset buttons (`0g`, `0.17g Lunar`, `0.38g Mars`, `1.0g Earth`) snaps targets smoothly; toggling `Cycle All` sweeps automatically across shapes and color regimes; dragging/scrolling in the viewport orbits and zooms freely with `Reset View` restoring the framing.

### Visual Identity & Theme
- **Aesthetic Direction**: Calibrated dark aerospace instrument console—clean, minimal, high-contrast, with zero marketing copy, zero pill badges, and zero decorative status dots.
- **Color Palette (60-30-10 Obsidian System)**:
  - **60% Primary Viewport & Canvas**: Deep space obsidian (`#07090E`) with matching `FogExp2` atmosphere so flame edges dissolve naturally.
  - **30% Structural Parameter Panel**: Matte dark slate (`#0D111A`) separated by crisp `1px` hairline borders (`#1E293B`), avoiding `backdrop-filter` over WebGL.
  - **10% Precision Telemetry Accents**: Calibrated amber (`#F59E0B`) for active sliders/controls and crisp off-white (`#F1F5F9`) / muted slate (`#94A3B8`) typography.
- **Typography & Tabular Discipline**:
  - **Interface & Labels**: `Plus Jakarta Sans` (clean geometric sans, regular and semibold weights).
  - **Measurements, Coordinates & Readouts**: `DM Mono` with `tabular-nums` so fluctuating values (`g`, `%`, `kPa`, `mm/s`, `T∞ K`) never cause layout jitter.
- **Component Styling & Layout**:
  - Single-viewport (`100vh`) asymmetric split console on desktop (`340px` left control rail + `flex-1` WebGL stage); responsive stacked layout on mobile viewports.
  - Unboxed inline telemetry corner overlay inside the 3D viewport showing active regime, gravity/oxygen/pressure summary, and flame temperature (`T∞`), plus subtle viewport controls (`Cycle All`, `Reset View`) anchored cleanly without obstructing the centered flame.

---

## 3. Key Product Decisions & Trade-Offs

- **Complete Codebase Pruning**:
  - *Chosen Approach*: Remove all unused PyroSage sections (landing hero, facts strip, specimen upload cards, 36-job screening runner, weighted ranking table, light/dark theme toggle, and the 9-part burner assembly module) rather than hiding them behind flags.
  - *Why*: Eliminates dead code, reduces bundle size, and guarantees zero visual or architectural leftovers.
  - *Alternatives Considered*: Keeping burner hardware toggleable or keeping navigation tabs—rejected because the goal is a pure flame-and-parameters-only tool.

- **Pure Floating Flame Grounding & Lighting**:
  - *Chosen Approach*: Remove all solid burner meshes while keeping a subtle soft radial ember glow / faint ambient light pool beneath the flame, paired with `RoomEnvironment` IBL, `ACESFilmicToneMapping`, and a flame-synced `PointLight` illuminating rising/radiating `InstancedMesh` embers.
  - *Why*: Without a solid pedestal, a flame-synced ambient glow and drifting embers preserve spatial depth and 3D orientation when orbiting while keeping the subject 100% pure fire.
  - *Alternatives Considered*: Leaving an invisible floor or floating completely featureless—less readable during 360-degree camera orbits.

- **Damped Parameter Transitions & Software-WebGL Safety**:
  - *Chosen Approach*: Drive uniform updates (`uGravity`, `uHeightScale`, `uWidthScale`, `uTurbulence`, `uColorCore/Mid/Outer/Base`) through exponential damping (`1 - Math.exp(-k * dt)`), pre-allocated scratch math objects, and hardware/software WebGL pacing (`afterDraw` for SwiftShader/llvmpipe, `requestAnimationFrame` for GPUs).
  - *Why*: Ensures fluid color and shape morphing without frame drops or React re-render stalls on the WebGL canvas.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                          App Root (Split Console)                       │
│  State: gravity | oxygen | pressure | fuelFlow | material | autoCycle   │
└───────────────────┬─────────────────────────────────┬───────────────────┘
                    │                                 │
                    ▼                                 ▼
┌───────────────────────────────────┐   ┌─────────────────────────────────┐
│      Left Parameter Console       │   │     Main 3D Flame Stage         │
│             (340px)               │   │         (flex-1 / full)         │
├───────────────────────────────────┤   ├─────────────────────────────────┤
│ • Gravity (0–1g) + Presets        │   │ ┌─────────────────────────────┐ │
│ • Oxygen Concentration (15–40%)   │   │ │   Isolated WebGL Container  │ │
│ • Cabin Pressure (10–200 kPa)     │   │ │   (Three.js Controller)     │ │
│ • Fuel Flow Rate (0.1–20 mm/s)    │   │ │                             │ │
│ • Material (PMMA/Cotton/Heptane)  │   │ │ • 3-Layer Volumetric Shader │ │
│ • Cycle All / Reset Defaults      │   │ │   Flame (FBM + Fresnel)     │ │
│                                   │   │ │ • InstancedMesh Embers      │ │
│ Live Physics Readout:             │   │ │ • Dynamic Flame PointLight  │ │
│  Regime · Spread Risk · Cool Flame│   │ │ • Damped OrbitControls      │ │
└───────────────────────────────────┘   │ └─────────────────────────────┘ │
                                        │  HUD: Mode · Conditions · T∞ K  │
                                        │  Actions: Cycle All · Reset View│
                                        └─────────────────────────────────┘
```

### Data Model & State
- **Combustion State**: Single immutable configuration object (`gravity`, `oxygen`, `pressure`, `fuelFlow`, `material`) plus a boolean `autoCycle` flag.
- **Derived Telemetry & Visual Targets**: Pure functions compute flame regime (`Spherical`, `Ellipsoidal`, `Teardrop`), spread risk (`Low`, `Medium`, `High`), cool-flame likelihood (`Likely`, `Possible`), estimated temperature (`T∞ K`), shape scale factors, turbulence velocity, and 4-stop thermal color targets (`core`, `mid`, `outer`, `base`).

### Interactive Component & State Mapping
- **Parameter Inputs (`number`, `range`, `select`)**: Immediately disable `autoCycle` on manual edit, clamp bounds safely, update React state for instant numeric/telemetry display, and push new targets into the Three.js controller ref without remounting the canvas.
- **Gravity Preset Buttons (`0g`, `0.17g Lunar`, `0.38g Mars`, `1.0g Earth`)**: Set `gravity` directly and smoothly damp the flame geometry from its current shape to the selected gravity regime.
- **Auto-Cycle Toggle (`Cycle All`)**: Alternates between manual parameter sculpting and continuous automated sweeps across gravity shapes (`0g` → `0.52g` → `0g`) and fuel/color states (amber-terracotta → cyan-indigo cool flame → golden plume), updating the live HUD telemetry at a throttled interval (~10Hz).
- **Camera Controls (`OrbitControls` + `Reset View`)**: Allows 360-degree orbit and zoom around the floating flame; clicking `Reset View` smoothly interpolates the camera back to its centered default framing and cancels automatically on user pointer drag.
