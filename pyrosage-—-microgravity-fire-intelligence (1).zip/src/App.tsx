import { useMemo, useState } from 'react';
import { FlameViewport } from './components/FlameViewport';
import { computeTelemetry, type CombustionParams, type FlameTelemetry, type FuelMaterial } from './three/flameTypes';

const DEFAULT_PARAMS: CombustionParams = {
  gravity: 0,
  oxygen: 21,
  pressure: 101,
  fuelFlow: 2,
  material: 'pmma',
};

const GRAVITY_PRESETS: Array<{ label: string; value: number }> = [
  { label: '0g', value: 0 },
  { label: '0.17g', value: 0.17 },
  { label: '0.38g', value: 0.38 },
  { label: '1.0g', value: 1 },
];

const MATERIAL_OPTIONS: Array<{ label: string; value: FuelMaterial }> = [
  { label: 'PMMA', value: 'pmma' },
  { label: 'Cotton', value: 'cotton' },
  { label: 'Heptane', value: 'heptane' },
];

export default function App() {
  const [params, setParams] = useState<CombustionParams>(DEFAULT_PARAMS);
  const [autoCycle, setAutoCycle] = useState<boolean>(false);
  const [cycleTelemetry, setCycleTelemetry] = useState<FlameTelemetry | null>(null);

  const manualTelemetry = useMemo(() => computeTelemetry(params), [params]);
  const activeTelemetry = autoCycle && cycleTelemetry ? cycleTelemetry : manualTelemetry;

  const updateParam = <K extends keyof CombustionParams>(key: K, value: CombustionParams[K]) => {
    setAutoCycle(false);
    setParams((prev) => ({ ...prev, [key]: value }));
  };

  const handleResetParams = () => {
    setAutoCycle(false);
    setParams(DEFAULT_PARAMS);
  };

  return (
    <div className="console-shell">
      <aside className="param-panel" aria-label="Flame parameters">
        <div className="panel-header">
          <h1 className="panel-title">Flame Parameters</h1>
          <button type="button" className="reset-link" onClick={handleResetParams}>
            Reset
          </button>
        </div>

        <div className="param-list">
          <div className="param-group">
            <div className="param-row">
              <label className="param-label" htmlFor="p-gravity">
                Gravity<span className="param-unit">g</span>
              </label>
              <input
                id="p-gravity"
                className="param-num"
                type="number"
                min={0}
                max={1}
                step={0.01}
                value={params.gravity}
                onChange={(e) =>
                  updateParam('gravity', Math.min(1, Math.max(0, Number(e.target.value) || 0)))
                }
              />
            </div>
            <input
              aria-label="Gravity slider"
              className="param-range"
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={params.gravity}
              onChange={(e) => updateParam('gravity', Number(e.target.value))}
            />
            <div className="preset-strip" role="group" aria-label="Gravity presets">
              {GRAVITY_PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  className="seg-btn"
                  aria-pressed={!autoCycle && params.gravity === preset.value}
                  onClick={() => updateParam('gravity', preset.value)}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          <div className="param-group">
            <div className="param-row">
              <label className="param-label" htmlFor="p-oxygen">
                Oxygen<span className="param-unit">%</span>
              </label>
              <input
                id="p-oxygen"
                className="param-num"
                type="number"
                min={15}
                max={40}
                step={1}
                value={params.oxygen}
                onChange={(e) =>
                  updateParam('oxygen', Math.min(40, Math.max(15, Number(e.target.value) || 15)))
                }
              />
            </div>
            <input
              aria-label="Oxygen concentration slider"
              className="param-range"
              type="range"
              min={15}
              max={40}
              step={1}
              value={params.oxygen}
              onChange={(e) => updateParam('oxygen', Number(e.target.value))}
            />
          </div>

          <div className="param-group">
            <div className="param-row">
              <label className="param-label" htmlFor="p-pressure">
                Cabin pressure<span className="param-unit">kPa</span>
              </label>
              <input
                id="p-pressure"
                className="param-num"
                type="number"
                min={10}
                max={200}
                step={1}
                value={params.pressure}
                onChange={(e) =>
                  updateParam('pressure', Math.min(200, Math.max(10, Number(e.target.value) || 10)))
                }
              />
            </div>
            <input
              aria-label="Cabin pressure slider"
              className="param-range"
              type="range"
              min={10}
              max={200}
              step={1}
              value={params.pressure}
              onChange={(e) => updateParam('pressure', Number(e.target.value))}
            />
          </div>

          <div className="param-group">
            <div className="param-row">
              <label className="param-label" htmlFor="p-flow">
                Fuel flow<span className="param-unit">mm/s</span>
              </label>
              <input
                id="p-flow"
                className="param-num"
                type="number"
                min={0.1}
                max={20}
                step={0.1}
                value={params.fuelFlow}
                onChange={(e) =>
                  updateParam('fuelFlow', Math.min(20, Math.max(0.1, Number(e.target.value) || 0.1)))
                }
              />
            </div>
            <input
              aria-label="Fuel flow slider"
              className="param-range"
              type="range"
              min={0.1}
              max={20}
              step={0.1}
              value={params.fuelFlow}
              onChange={(e) => updateParam('fuelFlow', Number(e.target.value))}
            />
          </div>

          <div className="param-group">
            <span className="param-label">Material</span>
            <div className="seg-strip" role="group" aria-label="Fuel material">
              {MATERIAL_OPTIONS.map((mat) => (
                <button
                  key={mat.value}
                  type="button"
                  className="seg-btn"
                  aria-pressed={!autoCycle && params.material === mat.value}
                  onClick={() => updateParam('material', mat.value)}
                >
                  {mat.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <dl className="readout-grid">
          <div>
            <dt>Regime</dt>
            <dd>{activeTelemetry.regime}</dd>
          </div>
          <div>
            <dt>Spread risk</dt>
            <dd>{activeTelemetry.spreadRisk}</dd>
          </div>
          <div>
            <dt>Cool flame</dt>
            <dd>{activeTelemetry.coolFlame}</dd>
          </div>
        </dl>
      </aside>

      <main className="viewport-main">
        <FlameViewport
          params={params}
          autoCycle={autoCycle}
          onToggleAutoCycle={() => setAutoCycle((prev) => !prev)}
          onTelemetrySync={(telemetry) => setCycleTelemetry(telemetry)}
        />
      </main>
    </div>
  );
}
