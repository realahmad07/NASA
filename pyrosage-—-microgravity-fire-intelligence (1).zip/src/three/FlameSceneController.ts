import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { createFlameShaderMaterial, type FlameLayerUniforms } from './flameShaders';
import {
  computeFlameVisuals,
  computeTelemetry,
  type CombustionParams,
  type FlameTelemetry,
} from './flameTypes';

export interface FlameControllerOptions {
  container: HTMLDivElement;
  initialParams?: CombustionParams;
  onTelemetry?: (telemetry: FlameTelemetry, effectiveParams: CombustionParams) => void;
  onContextLost?: (lost: boolean) => void;
}

// Pre-allocated scratch helpers (zero GC in render loop)
const _mat4 = new THREE.Matrix4();
const _pos = new THREE.Vector3();
const _quat = new THREE.Quaternion();
const _scale = new THREE.Vector3();
const _color = new THREE.Color();
const _targetCore = new THREE.Color();
const _targetMid = new THREE.Color();
const _targetOuter = new THREE.Color();
const _targetBase = new THREE.Color();
const _targetLight = new THREE.Color();

function detectSoftwareWebGL(): boolean {
  try {
    const probe = document.createElement('canvas');
    const gl = probe.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createRadiantPoolTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(128, 128, 6, 128, 128, 124);
  grad.addColorStop(0, 'rgba(255, 196, 120, 0.34)');
  grad.addColorStop(0.42, 'rgba(229, 105, 63, 0.12)');
  grad.addColorStop(1, 'rgba(7, 9, 14, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

interface EmberParticle {
  angle: number;
  radialSpeed: number;
  riseSpeed: number;
  phase: number;
  life: number;
  maxLife: number;
  size: number;
}

const EMBER_COUNT = 56;
const OBSIDIAN_BG = '#07090E';

export class FlameSceneController {
  private container: HTMLDivElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private flameGroup: THREE.Group;
  private flameGeo: THREE.BufferGeometry;
  private flameLayers: Array<{ mesh: THREE.Mesh; uniforms: FlameLayerUniforms }> = [];
  private flameMaterials: THREE.ShaderMaterial[] = [];
  private radiantPoolMesh: THREE.Mesh;
  private radiantPoolGeo: THREE.BufferGeometry;
  private radiantPoolMat: THREE.MeshBasicMaterial;
  private radiantPoolTex: THREE.CanvasTexture;
  private emberMesh: THREE.InstancedMesh;
  private emberGeo: THREE.BufferGeometry;
  private emberMat: THREE.MeshBasicMaterial;
  private embers: EmberParticle[] = [];
  private flamePointLight: THREE.PointLight;
  private envRT: THREE.WebGLRenderTarget;

  private isSoftwareGl: boolean;
  private reducedMotion: boolean;
  private frameId = 0;
  private disposed = false;
  private clock = new THREE.Clock();
  private elapsed = 0;
  private lastTelemetryEmit = -1;

  private autoCycle = false;
  private params: CombustionParams;
  private currentGravity: number;
  private currentHeightScale = 1.0;
  private currentWidthScale = 1.0;
  private currentTurbulence = 0.35;
  private currentSpeed = 1.3;
  private currentCoolFlame = 0.1;
  private currentBlueBase = 0.4;
  private currentIntensity = 1.2;

  private defaultCamPos = new THREE.Vector3(0.25, 0.35, 3.9);
  private defaultTarget = new THREE.Vector3(0, 0.15, 0);
  private resettingCamera = false;

  private resizeObserver: ResizeObserver;
  private onTelemetry?: (telemetry: FlameTelemetry, effectiveParams: CombustionParams) => void;
  private onContextLost?: (lost: boolean) => void;

  private handleContextLost = (e: Event) => {
    e.preventDefault();
    this.onContextLost?.(true);
  };

  private handleContextRestored = () => {
    this.onContextLost?.(false);
  };

  constructor(options: FlameControllerOptions) {
    this.container = options.container;
    this.onTelemetry = options.onTelemetry;
    this.onContextLost = options.onContextLost;
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    this.params = options.initialParams ?? {
      gravity: 0,
      oxygen: 21,
      pressure: 101,
      fuelFlow: 2,
      material: 'pmma',
    };
    this.currentGravity = this.params.gravity;

    this.isSoftwareGl = detectSoftwareWebGL();
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      alpha: false,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));

    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);
    this.renderer.setSize(width, height);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.addEventListener('webglcontextrestored', this.handleContextRestored);
    this.container.appendChild(this.renderer.domElement);

    // Deep obsidian scene & matching exponential fog
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(OBSIDIAN_BG);
    this.scene.fog = new THREE.FogExp2(OBSIDIAN_BG, 0.042);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.envRT = pmrem.fromScene(new RoomEnvironment(), 0.04);
    this.scene.environment = this.envRT.texture;
    pmrem.dispose();

    // Camera
    this.camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 60);
    this.camera.position.copy(this.defaultCamPos);

    // Damped OrbitControls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.copy(this.defaultTarget);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.07;
    this.controls.enablePan = false;
    this.controls.minDistance = 1.8;
    this.controls.maxDistance = 7.5;
    this.controls.minPolarAngle = 0.2;
    this.controls.maxPolarAngle = Math.PI * 0.72;
    this.controls.addEventListener('start', () => {
      this.resettingCamera = false;
    });

    // Subtle atmospheric lighting + dynamic flame PointLight
    const hemiLight = new THREE.HemisphereLight('#64748B', '#090D16', 0.45);
    this.scene.add(hemiLight);

    this.flamePointLight = new THREE.PointLight('#E5693F', 3.4, 9.0, 1.6);
    this.flamePointLight.position.set(0, 0.15, 0);
    this.scene.add(this.flamePointLight);

    // Soft radiant light pool below floating flame for subtle spatial depth (no hardware)
    this.radiantPoolTex = createRadiantPoolTexture();
    this.radiantPoolTex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
    this.radiantPoolGeo = new THREE.PlaneGeometry(4.2, 4.2);
    this.radiantPoolMat = new THREE.MeshBasicMaterial({
      map: this.radiantPoolTex,
      color: new THREE.Color('#E5693F'),
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      opacity: 0.48,
    });
    this.radiantPoolMesh = new THREE.Mesh(this.radiantPoolGeo, this.radiantPoolMat);
    this.radiantPoolMesh.rotation.x = -Math.PI / 2;
    this.radiantPoolMesh.position.y = -1.25;
    this.scene.add(this.radiantPoolMesh);

    // Pure Floating Volumetric 3D Flame
    this.flameGroup = new THREE.Group();
    this.flameGroup.position.set(0, 0, 0);
    this.scene.add(this.flameGroup);

    this.flameGeo = new THREE.IcosahedronGeometry(0.76, 5);

    const layerConfigs = [
      { layerScale: 0.56, opacity: 0.96, blending: THREE.AdditiveBlending, order: 3 },
      { layerScale: 0.88, opacity: 0.82, blending: THREE.NormalBlending, order: 2 },
      { layerScale: 1.18, opacity: 0.45, blending: THREE.AdditiveBlending, order: 4 },
    ];

    for (const cfg of layerConfigs) {
      const { material, uniforms } = createFlameShaderMaterial({
        layerScale: cfg.layerScale,
        opacity: cfg.opacity,
        blending: cfg.blending,
      });
      const mesh = new THREE.Mesh(this.flameGeo, material);
      mesh.renderOrder = cfg.order;
      this.flameGroup.add(mesh);
      this.flameLayers.push({ mesh, uniforms });
      this.flameMaterials.push(material);
    }

    // InstancedMesh Glowing Embers
    this.emberGeo = new THREE.SphereGeometry(0.017, 8, 8);
    this.emberMat = new THREE.MeshBasicMaterial({
      color: '#FFFFFF',
      transparent: true,
      opacity: 0.92,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.emberMesh = new THREE.InstancedMesh(this.emberGeo, this.emberMat, EMBER_COUNT);
    this.emberMesh.frustumCulled = false;
    this.emberMesh.renderOrder = 5;
    this.flameGroup.add(this.emberMesh);

    for (let i = 0; i < EMBER_COUNT; i++) {
      const maxLife = 1.6 + Math.random() * 2.2;
      this.embers.push({
        angle: (i / EMBER_COUNT) * Math.PI * 2 + Math.random() * 0.5,
        radialSpeed: 0.2 + Math.random() * 0.3,
        riseSpeed: 0.42 + Math.random() * 0.8,
        phase: Math.random() * Math.PI * 2,
        life: Math.random() * maxLife,
        maxLife,
        size: 0.45 + Math.random() * 0.95,
      });
    }

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);

    this.clock.start();
    this.tick();
  }

  public setParams(params: CombustionParams) {
    this.params = { ...params };
  }

  public setAutoCycle(enabled: boolean) {
    this.autoCycle = enabled;
  }

  public resetCamera() {
    this.resettingCamera = true;
  }

  private handleResize() {
    if (this.disposed) return;
    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private getEffectiveParams(t: number): CombustionParams {
    if (!this.autoCycle) return this.params;

    const cycle = (t * 0.16) % 4;
    const smoothPhase = (x: number) => 0.5 - 0.5 * Math.cos(x * Math.PI);

    if (cycle < 1) {
      const k = smoothPhase(cycle);
      return {
        gravity: 0.0,
        oxygen: Math.round(21 + k * 4),
        pressure: 101,
        fuelFlow: 2.2,
        material: 'pmma',
      };
    } else if (cycle < 2) {
      const k = smoothPhase(cycle - 1);
      return {
        gravity: Number((k * 0.17).toFixed(2)),
        oxygen: Math.round(21 - k * 3),
        pressure: 85,
        fuelFlow: 1.8,
        material: 'heptane',
      };
    } else if (cycle < 3) {
      const k = smoothPhase(cycle - 2);
      return {
        gravity: Number((0.17 + k * 0.55).toFixed(2)),
        oxygen: Math.round(24 + k * 12),
        pressure: 115,
        fuelFlow: 3.4,
        material: 'cotton',
      };
    } else {
      const k = smoothPhase(cycle - 3);
      return {
        gravity: Number((0.72 * (1 - k)).toFixed(2)),
        oxygen: Math.round(36 - k * 15),
        pressure: 101,
        fuelFlow: 2.2,
        material: 'pmma',
      };
    }
  }

  private tick = () => {
    if (this.disposed) return;

    const rawDelta = Math.min(0.05, this.clock.getDelta());
    const dt = this.reducedMotion ? rawDelta * 0.15 : rawDelta;
    this.elapsed += dt;

    const effective = this.getEffectiveParams(this.elapsed);
    const visuals = computeFlameVisuals(effective, this.elapsed * 0.85);
    const telemetry = computeTelemetry(effective);

    const dampK = 5.5;
    const alpha = 1 - Math.exp(-dampK * Math.max(dt, 0.016));

    this.currentGravity = THREE.MathUtils.lerp(this.currentGravity, visuals.gravity, alpha);
    this.currentHeightScale = THREE.MathUtils.lerp(this.currentHeightScale, visuals.heightScale, alpha);
    this.currentWidthScale = THREE.MathUtils.lerp(this.currentWidthScale, visuals.widthScale, alpha);
    this.currentTurbulence = THREE.MathUtils.lerp(this.currentTurbulence, visuals.turbulence, alpha);
    this.currentSpeed = THREE.MathUtils.lerp(this.currentSpeed, visuals.speed, alpha);
    this.currentCoolFlame = THREE.MathUtils.lerp(this.currentCoolFlame, visuals.coolFlameMix, alpha);
    this.currentBlueBase = THREE.MathUtils.lerp(this.currentBlueBase, visuals.blueBaseMix, alpha);
    this.currentIntensity = THREE.MathUtils.lerp(this.currentIntensity, visuals.intensity, alpha);

    _targetCore.set(visuals.coreHex);
    _targetMid.set(visuals.midHex);
    _targetOuter.set(visuals.outerHex);
    _targetBase.set(visuals.baseHex);
    _targetLight.set(visuals.lightHex);

    // Subtle vertical centering offset so tall buoyant plumes remain centered in frame
    this.flameGroup.position.y = -this.currentGravity * 0.28;

    for (const layer of this.flameLayers) {
      const u = layer.uniforms;
      u.uTime.value = this.elapsed;
      u.uGravity.value = this.currentGravity;
      u.uHeightScale.value = this.currentHeightScale;
      u.uWidthScale.value = this.currentWidthScale;
      u.uTurbulence.value = this.currentTurbulence;
      u.uSpeed.value = this.currentSpeed;
      u.uCoolFlame.value = this.currentCoolFlame;
      u.uBlueBase.value = this.currentBlueBase;
      u.uIntensity.value = this.currentIntensity;
      u.uColorCore.value.lerp(_targetCore, alpha);
      u.uColorMid.value.lerp(_targetMid, alpha);
      u.uColorOuter.value.lerp(_targetOuter, alpha);
      u.uColorBase.value.lerp(_targetBase, alpha);
    }

    const flicker = 0.92 + Math.sin(this.elapsed * 9.5) * 0.05 + Math.cos(this.elapsed * 14.3) * 0.04;
    this.flamePointLight.color.lerp(_targetLight, alpha);
    this.flamePointLight.intensity = (2.8 + this.currentIntensity * 0.9) * flicker;
    this.flamePointLight.position.y = 0.1 + this.currentGravity * 0.25;

    this.radiantPoolMat.color.lerp(_targetMid, alpha);
    this.radiantPoolMat.opacity = 0.36 + this.currentIntensity * 0.12 * flicker;

    // Update InstancedMesh ember particles
    const g = this.currentGravity;
    for (let i = 0; i < EMBER_COUNT; i++) {
      const e = this.embers[i];
      e.life += dt * (0.7 + g * 0.8);
      if (e.life >= e.maxLife) {
        e.life = 0;
        e.angle = Math.random() * Math.PI * 2;
      }
      const p = e.life / e.maxLife;
      const fade = Math.sin(p * Math.PI);

      const radialSpread = (0.16 + p * (0.95 - g * 0.45)) * this.currentWidthScale;
      const swirl = e.angle + this.elapsed * (0.35 + g * 1.1) + p * 1.8;
      const x = Math.cos(swirl) * radialSpread;
      const z = Math.sin(swirl) * radialSpread;
      const yRadial = Math.sin(e.phase + p * Math.PI * 0.5) * 0.4 * (1 - g * 0.6);
      const yBuoyant = p * e.riseSpeed * (0.3 + g * 2.0) * this.currentHeightScale;
      const y = yRadial + yBuoyant;

      _pos.set(x, y, z);
      const s = e.size * fade * (0.65 + this.currentIntensity * 0.25);
      _scale.set(s, s * (1 + g * 1.2), s);
      _mat4.compose(_pos, _quat, _scale);
      this.emberMesh.setMatrixAt(i, _mat4);

      _color.copy(_targetCore).lerp(_targetOuter, p * 0.85);
      this.emberMesh.setColorAt(i, _color);
    }
    this.emberMesh.instanceMatrix.needsUpdate = true;
    if (this.emberMesh.instanceColor) {
      this.emberMesh.instanceColor.needsUpdate = true;
    }

    if (this.resettingCamera) {
      const camAlpha = 1 - Math.exp(-6.0 * Math.max(dt, 0.016));
      this.camera.position.lerp(this.defaultCamPos, camAlpha);
      this.controls.target.lerp(this.defaultTarget, camAlpha);
      if (this.camera.position.distanceTo(this.defaultCamPos) < 0.02) {
        this.camera.position.copy(this.defaultCamPos);
        this.controls.target.copy(this.defaultTarget);
        this.resettingCamera = false;
      }
    }

    this.controls.update();
    this.renderer.render(this.scene, this.camera);

    if (this.onTelemetry && this.elapsed - this.lastTelemetryEmit > 0.1) {
      this.lastTelemetryEmit = this.elapsed;
      this.onTelemetry(telemetry, effective);
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private afterDraw(cb: () => void) {
    if (this.disposed) return;
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.resizeObserver.disconnect();
    this.controls.dispose();
    this.flameGeo.dispose();
    this.flameMaterials.forEach((m) => m.dispose());
    this.radiantPoolGeo.dispose();
    this.radiantPoolMat.dispose();
    this.radiantPoolTex.dispose();
    this.emberGeo.dispose();
    this.emberMat.dispose();
    this.envRT.dispose();
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.removeEventListener('webglcontextrestored', this.handleContextRestored);
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
