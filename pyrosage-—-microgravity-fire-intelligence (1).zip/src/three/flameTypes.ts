export type FuelMaterial = 'pmma' | 'cotton' | 'heptane';

export interface CombustionParams {
  gravity: number; // 0 to 1 g
  oxygen: number; // 15 to 40 %
  pressure: number; // 10 to 200 kPa
  fuelFlow: number; // 0.1 to 20 mm/s
  material: FuelMaterial;
}

export interface FlameTelemetry {
  regime: 'Spherical' | 'Ellipsoidal' | 'Teardrop';
  spreadRisk: 'Low' | 'Medium' | 'High';
  coolFlame: 'Likely' | 'Possible';
  temperatureK: number;
  flowLabel: string;
  modeLabel: string;
}

export interface FlameVisualTargets {
  gravity: number;
  heightScale: number;
  widthScale: number;
  turbulence: number;
  speed: number;
  coolFlameMix: number;
  blueBaseMix: number;
  coreHex: string;
  midHex: string;
  outerHex: string;
  baseHex: string;
  lightHex: string;
  intensity: number;
}

export function computeTelemetry(params: CombustionParams): FlameTelemetry {
  const { gravity, oxygen, pressure, material } = params;
  const regime: FlameTelemetry['regime'] =
    gravity < 0.05 ? 'Spherical' : gravity < 0.3 ? 'Ellipsoidal' : 'Teardrop';

  const spreadRisk: FlameTelemetry['spreadRisk'] =
    oxygen > 30 && material === 'cotton' ? 'High' : gravity > 0.2 ? 'Medium' : 'Low';

  const coolFlame: FlameTelemetry['coolFlame'] =
    material === 'heptane' && oxygen < 25 ? 'Likely' : 'Possible';

  const baseTemp = 500 + oxygen * 14 + (pressure - 101) * 0.45 + (material === 'pmma' ? 40 : material === 'cotton' ? 20 : 60);
  const coolReduction = coolFlame === 'Likely' && gravity < 0.12 ? 170 : 0;
  const temperatureK = Math.round(Math.max(420, baseTemp - coolReduction));

  const flowLabel = gravity < 0.1 ? 'MARANGONI' : gravity < 0.3 ? 'MIXED CONVECTION' : 'BUOYANT PLUME';
  const modeLabel =
    gravity < 0.05
      ? '0g · SPHERICAL'
      : gravity < 0.22
        ? `${gravity.toFixed(2)}g · LUNAR`
        : gravity < 0.5
          ? `${gravity.toFixed(2)}g · MARTIAN`
          : `${gravity.toFixed(2)}g · BUOYANT`;

  return {
    regime,
    spreadRisk,
    coolFlame,
    temperatureK,
    flowLabel,
    modeLabel,
  };
}

export function computeFlameVisuals(params: CombustionParams, colorPhase = 0): FlameVisualTargets {
  const g = Math.min(1, Math.max(0, params.gravity));
  const oxNorm = Math.min(1, Math.max(0, (params.oxygen - 15) / 25));
  const prNorm = Math.min(1.8, Math.max(0.45, params.pressure / 101));
  const flNorm = Math.min(1.7, Math.max(0.55, Math.pow(params.fuelFlow / 2, 0.28)));

  // Physical shape envelope
  const baseSize = (0.72 + oxNorm * 0.34) * (0.75 + prNorm * 0.25) * flNorm;
  const heightScale = baseSize * (0.86 + g * 1.12);
  const widthScale = baseSize * (1.05 - g * 0.42);

  // Cool flame indicator for heptane in low oxygen + low gravity
  const isCool = params.material === 'heptane' && params.oxygen < 25;
  const coolFlameMix = isCool ? (g < 0.2 ? 0.92 : 0.48) : 0.08 + (1 - oxNorm) * 0.14;

  // Dynamic color palettes by fuel chemistry & oxygen concentration
  // Subtle harmonic drift from colorPhase allows fire to subtly evolve hues organically
  const shift = Math.sin(colorPhase) * 0.5 + 0.5;

  let coreHex = '#FFF3C4';
  let midHex = '#E5693F';
  let outerHex = '#B4411F';
  let baseHex = '#38BDF8';
  let lightHex = '#F58A42';

  if (isCool && g < 0.25) {
    // Cool-flame regime: luminous cyan / indigo / violet-blue
    coreHex = shift > 0.5 ? '#E0F7FF' : '#D8E8FF';
    midHex = shift > 0.5 ? '#38BDF8' : '#60A5FA';
    outerHex = shift > 0.5 ? '#4F46E5' : '#1F4D45';
    baseHex = '#67E8F9';
    lightHex = '#5BB8F5';
  } else if (params.material === 'heptane') {
    // Hydrocarbon droplet: strong blue CH* reaction base + golden-amber soot tip
    coreHex = oxNorm > 0.6 ? '#FFFBEB' : '#FCE8A6';
    midHex = shift > 0.5 ? '#F59E0B' : '#E5693F';
    outerHex = oxNorm > 0.7 ? '#3B82F6' : '#B4411F';
    baseHex = '#2563EB';
    lightHex = '#F5A33B';
  } else if (params.material === 'cotton') {
    // Cellulose: bright incandescent yellow-orange + deep ember crimson
    coreHex = '#FFF7D6';
    midHex = shift > 0.5 ? '#F2B84B' : '#EB7D3C';
    outerHex = shift > 0.5 ? '#B4411F' : '#9E2A1C';
    baseHex = '#F59E0B';
    lightHex = '#F29544';
  } else {
    // PMMA: rich PyroSage terracotta-to-gold soot mantle with faint blue quench rim
    coreHex = oxNorm > 0.65 ? '#FFF8E1' : '#F6CA65';
    midHex = shift > 0.5 ? '#E5693F' : '#EB7E44';
    outerHex = shift > 0.5 ? '#B4411F' : '#8E2B14';
    baseHex = oxNorm > 0.45 ? '#3B82F6' : '#B98A2E';
    lightHex = '#E5693F';
  }

  return {
    gravity: g,
    heightScale,
    widthScale,
    turbulence: 0.22 + g * 0.62 + oxNorm * 0.22,
    speed: 1.05 + g * 1.65 + (params.fuelFlow / 20) * 0.9,
    coolFlameMix,
    blueBaseMix: params.material === 'heptane' ? 0.85 : oxNorm * 0.55,
    coreHex,
    midHex,
    outerHex,
    baseHex,
    lightHex,
    intensity: 1.1 + oxNorm * 0.55,
  };
}
