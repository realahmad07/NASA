import * as THREE from 'three';

const SIMPLEX_NOISE_GLSL = /* glsl */ `
vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 permute(vec4 x) { return mod289(((x * 34.0) + 1.0) * x); }
vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }

float snoise(vec3 v) {
  const vec2 C = vec2(1.0 / 6.0, 1.0 / 3.0);
  const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);

  vec3 i  = floor(v + dot(v, C.yyy));
  vec3 x0 = v - i + dot(i, C.xxx);

  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min(g.xyz, l.zxy);
  vec3 i2 = max(g.xyz, l.zxy);

  vec3 x1 = x0 - i1 + C.xxx;
  vec3 x2 = x0 - i2 + C.yyy;
  vec3 x3 = x0 - D.yyy;

  i = mod289(i);
  vec4 p = permute(permute(permute(
             i.z + vec4(0.0, i1.z, i2.z, 1.0))
           + i.y + vec4(0.0, i1.y, i2.y, 1.0))
           + i.x + vec4(0.0, i1.x, i2.x, 1.0));

  float n_ = 0.142857142857;
  vec3 ns = n_ * D.wyz - D.xzx;

  vec4 j = p - 49.0 * floor(p * ns.z * ns.z);

  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_);

  vec4 x = x_ * ns.x + ns.yyyy;
  vec4 y = y_ * ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);

  vec4 b0 = vec4(x.xy, y.xy);
  vec4 b1 = vec4(x.zw, y.zw);

  vec4 s0 = floor(b0) * 2.0 + 1.0;
  vec4 s1 = floor(b1) * 2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));

  vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy;
  vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;

  vec3 p0 = vec3(a0.xy, h.x);
  vec3 p1 = vec3(a0.zw, h.y);
  vec3 p2 = vec3(a1.xy, h.z);
  vec3 p3 = vec3(a1.zw, h.w);

  vec4 norm = taylorInvSqrt(vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3)));
  p0 *= norm.x;
  p1 *= norm.y;
  p2 *= norm.z;
  p3 *= norm.w;

  vec4 m = max(0.6 - vec4(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3)), 0.0);
  m = m * m;
  return 42.0 * dot(m * m, vec4(dot(p0, x0), dot(p1, x1), dot(p2, x2), dot(p3, x3)));
}

float fbm(vec3 p) {
  float value = 0.0;
  float amp = 0.52;
  float freq = 1.0;
  for (int i = 0; i < 4; i++) {
    value += amp * snoise(p * freq);
    freq *= 2.04;
    amp *= 0.48;
  }
  return value;
}
`;

export interface FlameLayerUniforms {
  [uniform: string]: THREE.IUniform<unknown>;
  uTime: THREE.IUniform<number>;
  uGravity: THREE.IUniform<number>;
  uHeightScale: THREE.IUniform<number>;
  uWidthScale: THREE.IUniform<number>;
  uTurbulence: THREE.IUniform<number>;
  uSpeed: THREE.IUniform<number>;
  uLayerScale: THREE.IUniform<number>;
  uOpacity: THREE.IUniform<number>;
  uCoolFlame: THREE.IUniform<number>;
  uBlueBase: THREE.IUniform<number>;
  uIntensity: THREE.IUniform<number>;
  uColorCore: THREE.IUniform<THREE.Color>;
  uColorMid: THREE.IUniform<THREE.Color>;
  uColorOuter: THREE.IUniform<THREE.Color>;
  uColorBase: THREE.IUniform<THREE.Color>;
}

export function createFlameShaderMaterial(options: {
  layerScale: number;
  opacity: number;
  blending: THREE.Blending;
}): { material: THREE.ShaderMaterial; uniforms: FlameLayerUniforms } {
  const uniforms: FlameLayerUniforms = {
    uTime: { value: 0 },
    uGravity: { value: 0 },
    uHeightScale: { value: 1.0 },
    uWidthScale: { value: 1.0 },
    uTurbulence: { value: 0.35 },
    uSpeed: { value: 1.4 },
    uLayerScale: { value: options.layerScale },
    uOpacity: { value: options.opacity },
    uCoolFlame: { value: 0.1 },
    uBlueBase: { value: 0.4 },
    uIntensity: { value: 1.2 },
    uColorCore: { value: new THREE.Color('#FFF3C4') },
    uColorMid: { value: new THREE.Color('#E5693F') },
    uColorOuter: { value: new THREE.Color('#B4411F') },
    uColorBase: { value: new THREE.Color('#38BDF8') },
  };

  const vertexShader = /* glsl */ `
    ${SIMPLEX_NOISE_GLSL}

    uniform float uTime;
    uniform float uGravity;
    uniform float uHeightScale;
    uniform float uWidthScale;
    uniform float uTurbulence;
    uniform float uSpeed;
    uniform float uLayerScale;

    varying vec3 vLocalPos;
    varying vec3 vWorldPos;
    varying vec3 vNormalWorld;
    varying float vHeightNorm;
    varying float vNoiseVal;

    void main() {
      vec3 dir = normalize(position);
      float yNorm = dir.y * 0.5 + 0.5; // 0 at bottom, 1 at top

      // Morph from spherical 0g shell -> ellipsoidal 0.17g -> buoyant teardrop plume 0.38g..1g
      float gFactor = clamp(uGravity, 0.0, 1.0);

      // Taper top smoothly as gravity creates convective buoyancy
      float plumeTaper = mix(1.0, pow(max(0.08, 1.0 - yNorm * 0.86), 0.72), gFactor);
      // Slight belly fullness near lower third in buoyant mode
      float belly = mix(1.0, 1.18 - yNorm * 0.45 + sin(yNorm * 3.14159) * 0.18, gFactor);

      vec3 morphed = vec3(
        dir.x * uWidthScale * plumeTaper * belly,
        dir.y * uHeightScale,
        dir.z * uWidthScale * plumeTaper * belly
      );

      // Lift flame center upward as gravity increases so bottom sits over burner
      morphed.y += gFactor * uHeightScale * 0.48;

      // Continuous organic combustion turbulence
      float t = uTime * uSpeed;
      vec3 flowCoord = dir * (1.8 + gFactor * 1.4) - vec3(0.0, t * (0.45 + gFactor * 1.15), 0.0);
      float n1 = fbm(flowCoord);
      float n2 = snoise(dir * 3.2 + vec3(t * 0.35, -t * 1.3, t * 0.25));

      // Gentle breathing pulse in 0g Marangoni mode + licking tongues in buoyant mode
      float breathe = sin(uTime * 1.7 + n1 * 1.8) * (0.045 * (1.0 - gFactor * 0.5));
      float upwardLick = pow(yNorm, 1.3) * (n1 * 0.36 + n2 * 0.16) * uTurbulence;
      float radialRipple = n1 * 0.11 * (0.35 + gFactor * 0.65);

      // Subtle helical convective sway at higher gravity
      float sway = gFactor * pow(yNorm, 1.6) * 0.14;
      morphed.x += sin(t * 1.9 + yNorm * 4.0) * sway;
      morphed.z += cos(t * 1.6 + yNorm * 3.5) * sway;

      // Displace along outward radial direction + upward tip stretch
      morphed += dir * (breathe + radialRipple) * uLayerScale;
      morphed.y += upwardLick * uLayerScale * (0.35 + gFactor * 0.9);
      morphed *= uLayerScale;

      vLocalPos = morphed;
      vHeightNorm = yNorm;
      vNoiseVal = n1 * 0.5 + 0.5;

      vec4 worldPosition = modelMatrix * vec4(morphed, 1.0);
      vWorldPos = worldPosition.xyz;
      vNormalWorld = normalize(mat3(modelMatrix) * dir);

      gl_Position = projectionMatrix * viewMatrix * worldPosition;
    }
  `;

  const fragmentShader = /* glsl */ `
    ${SIMPLEX_NOISE_GLSL}

    uniform float uTime;
    uniform float uGravity;
    uniform float uSpeed;
    uniform float uOpacity;
    uniform float uCoolFlame;
    uniform float uBlueBase;
    uniform float uIntensity;
    uniform vec3 uColorCore;
    uniform vec3 uColorMid;
    uniform vec3 uColorOuter;
    uniform vec3 uColorBase;

    varying vec3 vLocalPos;
    varying vec3 vWorldPos;
    varying vec3 vNormalWorld;
    varying float vHeightNorm;
    varying float vNoiseVal;

    void main() {
      vec3 viewDir = normalize(cameraPosition - vWorldPos);
      float ndotv = abs(dot(normalize(vNormalWorld), viewDir));

      // Soft volumetric edge falloff so flame never has hard geometry edges
      float fresnelFade = pow(clamp(ndotv, 0.0, 1.0), 1.35);
      float rimGlow = pow(1.0 - clamp(ndotv, 0.0, 1.0), 2.2);

      // Dual-scale animated flame filaments
      float t = uTime * uSpeed;
      vec3 p = vLocalPos * 2.35 - vec3(0.0, t * (0.65 + uGravity * 1.15), 0.0);
      float filament = fbm(p);
      float micro = snoise(vLocalPos * 5.2 - vec3(0.0, t * 1.8, 0.0));
      float heat = clamp(0.55 + filament * 0.45 + micro * 0.22 + (1.0 - vHeightNorm) * 0.25, 0.0, 1.0);

      // Multi-stop thermal color gradient: outer -> mid -> core
      vec3 col = mix(uColorOuter, uColorMid, smoothstep(0.18, 0.62, heat));
      col = mix(col, uColorCore, smoothstep(0.58, 0.94, heat) * fresnelFade);

      // Hydrocarbon / lean blue CH* chemiluminescent reaction front at base & outer diffusion shell
      float baseZone = (1.0 - smoothstep(0.05, 0.42, vHeightNorm)) * uBlueBase;
      float outerDiffusionShell = rimGlow * (0.35 + uCoolFlame * 0.65);
      col = mix(col, uColorBase, clamp(baseZone * 0.78 + outerDiffusionShell * 0.48, 0.0, 0.85));

      // Gentle temporal color-temperature breathing
      float pulse = 0.92 + 0.14 * sin(uTime * 3.1 + vNoiseVal * 4.0);
      col *= uIntensity * pulse;

      // Tip dissolves smoothly into hot gases/soot wisps
      float tipFade = mix(1.0, smoothstep(1.02, 0.52, vHeightNorm + filament * 0.18), 0.3 + uGravity * 0.65);
      float alpha = fresnelFade * tipFade * uOpacity * (0.65 + 0.35 * heat);

      if (alpha < 0.01) discard;
      gl_FragColor = vec4(col, clamp(alpha, 0.0, 1.0));
    }
  `;

  const material = new THREE.ShaderMaterial({
    uniforms,
    vertexShader,
    fragmentShader,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    blending: options.blending,
  });

  return { material, uniforms };
}
