import { useEffect, useRef, useState } from 'react';
import { FlameSceneController } from '../three/FlameSceneController';
import { computeTelemetry, type CombustionParams, type FlameTelemetry } from '../three/flameTypes';

interface FlameViewportProps {
  params: CombustionParams;
  autoCycle: boolean;
  onToggleAutoCycle: () => void;
  onTelemetrySync?: (telemetry: FlameTelemetry, effective: CombustionParams) => void;
}

export function FlameViewport({
  params,
  autoCycle,
  onToggleAutoCycle,
  onTelemetrySync,
}: FlameViewportProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const controllerRef = useRef<FlameSceneController | null>(null);
  const onTelemetrySyncRef = useRef(onTelemetrySync);
  onTelemetrySyncRef.current = onTelemetrySync;

  const [contextLost, setContextLost] = useState(false);
  const [liveState, setLiveState] = useState<{
    telemetry: FlameTelemetry;
    effective: CombustionParams;
  }>(() => ({
    telemetry: computeTelemetry(params),
    effective: params,
  }));

  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    const controller = new FlameSceneController({
      container: el,
      initialParams: params,
      onTelemetry: (telemetry, effective) => {
        setLiveState({ telemetry, effective });
        onTelemetrySyncRef.current?.(telemetry, effective);
      },
      onContextLost: (lost) => setContextLost(lost),
    });
    controller.setAutoCycle(autoCycle);
    controllerRef.current = controller;

    return () => {
      controller.dispose();
      controllerRef.current = null;
    };
    // Mount WebGL scene once
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    controllerRef.current?.setParams(params);
  }, [params]);

  useEffect(() => {
    controllerRef.current?.setAutoCycle(autoCycle);
  }, [autoCycle]);

  return (
    <div className="viewport-stage">
      <div
        ref={mountRef}
        className="viewport-canvas"
        role="img"
        aria-label="Interactive 3D floating flame simulation"
      />

      {/* Top telemetry readout overlay (unboxed monospace, pointer-events-none) */}
      <div className="viewport-hud-top" aria-hidden="true">
        <div className="hud-stack">
          <span className="hud-primary">{liveState.telemetry.modeLabel}</span>
          <span className="hud-secondary">
            {liveState.telemetry.coolFlame === 'Likely' ? 'COOL FLAME' : liveState.telemetry.flowLabel}
          </span>
        </div>
        <div className="hud-stack hud-right tabular-nums">
          <span className="hud-primary">T∞ {liveState.telemetry.temperatureK} K</span>
          <span className="hud-secondary">
            {liveState.effective.gravity.toFixed(2)}g · {liveState.effective.oxygen}% O₂ ·{' '}
            {liveState.effective.pressure} kPa
          </span>
        </div>
      </div>

      {/* Bottom-right subtle viewport actions */}
      <div className="viewport-hud-bottom">
        <span className="hud-hint">Drag to orbit · Scroll to zoom</span>
        <div className="hud-actions">
          <button
            type="button"
            className="hud-btn"
            aria-pressed={autoCycle}
            onClick={onToggleAutoCycle}
          >
            {autoCycle ? 'Stop cycle' : 'Cycle all'}
          </button>
          <button
            type="button"
            className="hud-btn"
            onClick={() => controllerRef.current?.resetCamera()}
          >
            Reset view
          </button>
        </div>
      </div>

      {contextLost && (
        <div className="viewport-fallback">
          <span>WebGL context paused — 3D flame renderer recovering</span>
        </div>
      )}
    </div>
  );
}
